/* Shared by browser and server. Team attacks UP: goalkeeper at bottom.
 * Arrays retain historical persisted slot indices. Rows are DISPLAY left-to-right.
 * Pitch coordinates: x=0 left, x=100 right, y=0 own goal, y=100 opposition goal.
 * Tactical slot labels RCB/LCB describe the side without changing the player's
 * generalized CB role used by matchup and positional rating calculations.
 */
export const BASE_SLOTS=['GK','RB','CB','CB','LB','CDM','CM','CAM','RW','ST','LW'];
const build=(slots,rows,labels={})=>({slots,rows,labels:Object.fromEntries(Object.entries(labels).map(([i,v])=>[Number(i),v]))});
export const FORMATIONS={
 '4-3-3':build(BASE_SLOTS,[[10,9,8],[6,5,7],[4,3,2,1],[0]],{2:'RCB',3:'LCB'}),
 '4-2-3-1':build(['GK','RB','CB','CB','LB','CDM','CDM','CAM','RW','ST','LW'],[[9],[10,7,8],[5,6],[4,3,2,1],[0]],{2:'RCB',3:'LCB',5:'LCDM',6:'RCDM'}),
 '4-4-2':build(['GK','RB','CB','CB','LB','RM','CM','CM','LM','ST','ST'],[[9,10],[8,6,7,5],[4,3,2,1],[0]],{2:'RCB',3:'LCB',6:'LCM',7:'RCM',9:'LST',10:'RST'}),
 '3-5-2':build(['GK','CB','CB','CB','LM','CDM','CM','CAM','RM','ST','ST'],[[9,10],[4,5,6,7,8],[3,2,1],[0]],{1:'RCB',2:'CB',3:'LCB',9:'LST',10:'RST'}),
 '3-4-3':build(['GK','CB','CB','CB','LM','CM','CM','RM','LW','ST','RW'],[[8,9,10],[4,5,6,7],[3,2,1],[0]],{1:'RCB',2:'CB',3:'LCB',5:'LCM',6:'RCM'}),
 '5-3-2':build(['GK','RB','CB','CB','CB','LB','CDM','CM','CAM','ST','ST'],[[9,10],[6,7,8],[5,4,3,2,1],[0]],{2:'RCB',3:'CB',4:'LCB',9:'LST',10:'RST'}),
 '4-1-4-1':build(['GK','RB','CB','CB','LB','CDM','LM','CM','CAM','RM','ST'],[[10],[6,7,8,9],[5],[4,3,2,1],[0]],{2:'RCB',3:'LCB'}),
 '4-3-1-2':build(['GK','RB','CB','CB','LB','CDM','CM','CM','CAM','ST','ST'],[[9,10],[8],[7,5,6],[4,3,2,1],[0]],{2:'RCB',3:'LCB',7:'LCM',6:'RCM',9:'LST',10:'RST'}),
 '4-2-2-2':build(['GK','RB','CB','CB','LB','CDM','CDM','LM','RM','ST','ST'],[[9,10],[7,8],[5,6],[4,3,2,1],[0]],{2:'RCB',3:'LCB',5:'LCDM',6:'RCDM',9:'LST',10:'RST'}),
 '3-4-2-1':build(['GK','CB','CB','CB','LM','CM','CM','RM','CAM','CAM','ST'],[[10],[8,9],[4,5,6,7],[3,2,1],[0]],{1:'RCB',2:'CB',3:'LCB',5:'LCM',6:'RCM',8:'LCAM',9:'RCAM'}),
 '5-2-3':build(['GK','RB','CB','CB','CB','LB','CM','CM','LW','ST','RW'],[[8,9,10],[6,7],[5,4,3,2,1],[0]],{2:'RCB',3:'CB',4:'LCB',6:'LCM',7:'RCM'})
};
export const formationSlots=(shape='4-3-3')=>(FORMATIONS[shape]||FORMATIONS['4-3-3']).slots;
export const slotDisplayName=(shape,index)=>(FORMATIONS[shape]||FORMATIONS['4-3-3']).labels[index]||formationSlots(shape)[index];
export function formationCoordinates(shape='4-3-3'){
 const formation=FORMATIONS[shape]||FORMATIONS['4-3-3'];
 const coords=Array(11).fill(null);
 const rows=formation.rows;
 rows.forEach((indices,rowNumber)=>indices.forEach((i,j)=>{
  const x=(j+1)*100/(indices.length+1);
  const y=rows.length===1?50:8+(rows.length-1-rowNumber)*84/(rows.length-1);
  coords[i]={x,y,role:formation.slots[i],label:slotDisplayName(shape,i)};
 }));
 return coords;
}
export function validateFormationGeometry(shape){
 const f=FORMATIONS[shape];if(!f||f.slots.length!==11)return false;
 const values=f.rows.flat();if(values.length!==11||new Set(values).size!==11||values.some(n=>n<0||n>10))return false;
 const c=formationCoordinates(shape);const leftSide=['LB','LW','LM','LWB','LCB','LCM'];const rightSide=['RB','RW','RM','RWB','RCB','RCM'];
 for(const a of leftSide)for(const b of rightSide){const la=c.filter(x=>x.label===a),rb=c.filter(x=>x.label===b);if(la.length&&rb.length&&Math.max(...la.map(v=>v.x))>=Math.min(...rb.map(v=>v.x)))return false;}
 if(c[0].x!==50||c[0].y!==8)return false;
 return true;
}
