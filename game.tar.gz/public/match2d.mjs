// Lightweight Canvas 2D spectator rendering. No gameplay decisions are made here.
// All 22 player coordinates, possession, and goals originate from server snapshots.
export class MatchCanvas {
 constructor(canvas, names, colors){this.canvas=canvas;this.ctx=canvas.getContext('2d');this.names=names;this.colors=colors;this.from=null;this.to=null;this.received=0;this.live=true;this.previousTime=0;this.frame=this.frame.bind(this);this.resize();this.observer=new ResizeObserver(()=>this.resize());this.observer.observe(canvas);this.id=requestAnimationFrame(this.frame);}
 resize(){const c=this.canvas;if(!c?.isConnected)return;const r=c.getBoundingClientRect();this.width=Math.max(250,r.width);this.height=Math.max(140,r.height);const dpr=Math.min(window.devicePixelRatio||1,2);c.width=Math.round(this.width*dpr);c.height=Math.round(this.height*dpr);this.ctx.setTransform(dpr,0,0,dpr,0,0);}
 update(snapshot){if(!snapshot)return;this.from=this.to||snapshot;this.to=snapshot;this.received=performance.now();}
 stop(){this.live=false;cancelAnimationFrame(this.id);this.observer.disconnect();}
 frame(now){if(!this.live)return;this.id=requestAnimationFrame(this.frame);if(document.hidden||(!this.to))return;
  if(now-this.previousTime<16)return;this.previousTime=now;
  const ease=t=>t*t*(3-2*t),t=ease(Math.min(1,Math.max(0,(now-this.received)/330)));
  const old=new Map(this.from?.players?.map(p=>[p.team+':'+p.index,p])||[]);
  const players=this.to.players.map(p=>{const before=old.get(p.team+':'+p.index)||p;return {...p,x:before.x+(p.x-before.x)*t,y:before.y+(p.y-before.y)*t};});
  const prevBall=this.from?.ball||this.to.ball;const ball={x:prevBall.x+(this.to.ball.x-prevBall.x)*t,y:prevBall.y+(this.to.ball.y-prevBall.y)*t};
  this.draw(players,ball);
 }
 draw(players,ball){const ctx=this.ctx,w=this.width,h=this.height;
  const X=x=>w*(.035+.93*x/100),Y=y=>h*(.06+.88*y/100);ctx.clearRect(0,0,w,h);
  ctx.fillStyle='#0D3B34';ctx.fillRect(0,0,w,h);for(let i=0;i<10;i++){ctx.fillStyle=i%2?'#124D42':'#164A41';ctx.fillRect(w*i/10,0,w/10+1,h);}
  ctx.lineWidth=1.6;ctx.strokeStyle='rgba(194,246,213,.63)';ctx.strokeRect(X(0),Y(0),X(100)-X(0),Y(100)-Y(0));
  ctx.beginPath();ctx.moveTo(X(50),Y(0));ctx.lineTo(X(50),Y(100));ctx.stroke();ctx.beginPath();ctx.ellipse(X(50),Y(50),w*.09,h*.19,0,0,Math.PI*2);ctx.stroke();
  ctx.strokeRect(X(0),Y(22),X(17)-X(0),Y(78)-Y(22));ctx.strokeRect(X(83),Y(22),X(100)-X(83),Y(78)-Y(22));
  ctx.strokeRect(X(0),Y(37),X(6)-X(0),Y(63)-Y(37));ctx.strokeRect(X(94),Y(37),X(100)-X(94),Y(63)-Y(37));
  ctx.fillStyle='rgba(230,248,240,.65)';ctx.fillRect(X(0)-5,Y(42),5,Y(58)-Y(42));ctx.fillRect(X(100),Y(42),5,Y(58)-Y(42));
  const r=Math.max(7,Math.min(12,w/85));
  for(const p of players){const x=X(p.x),y=Y(p.y),color=this.colors[p.team]||'#DFEA7B';
   ctx.beginPath();ctx.arc(x,y,r+2,0,Math.PI*2);ctx.fillStyle='rgba(5,13,23,.85)';ctx.fill();ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();
   ctx.strokeStyle='rgba(255,255,255,.7)';ctx.lineWidth=1;ctx.stroke();ctx.fillStyle='#081625';ctx.font=`800 ${Math.max(8,r*.95)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(p.index+1,x,y+.5);
   if(w>420){ctx.font=`700 ${Math.max(8,Math.min(10,w/120))}px system-ui`;ctx.fillStyle='#F7F9E8';ctx.shadowColor='#061b19';ctx.shadowBlur=5;
    ctx.fillText(this.names[p.id]?.split(' ').at(-1)?.slice(0,12)||String(p.id).slice(-4),x,y+r+10);ctx.shadowBlur=0;}
  }
  const bx=X(ball.x),by=Y(ball.y);ctx.beginPath();ctx.arc(bx,by,Math.max(4,r*.53),0,Math.PI*2);ctx.fillStyle='#F8FFEC';ctx.shadowColor='#E4FF8A';ctx.shadowBlur=14;ctx.fill();ctx.shadowBlur=0;
 }
}
