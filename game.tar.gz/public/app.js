import {BASE_SLOTS,FORMATIONS,slotDisplayName,formationCoordinates} from './formations.mjs';
import {MatchCanvas} from './match2d.mjs';
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const app={socket:null,room:null,myId:null,view:'arena',catalog:[],byId:new Map(),serverOffset:0,
 selected:null,search:'',position:'',sort:'rank',page:0,bidDraft:'',tradeTo:'',giveId:'',wantId:'',cash:'0',
 motion:localStorage.getItem('far-motion')||'auto',sound:localStorage.getItem('far-sound')==='on',modalId:null,connected:false,
 squadViewer:null,tradeModal:false,tradePending:false,imageId:null,imageSearch:'',imageFile:null,imagePreview:null,auctionWarned:'',seenEvents:null,arenaPopupTimer:null,clubFocus:null,moveSource:null,movePending:false,editMode:false,pendingLineup:null,pendingShape:null,lastShape:null,creditEffects:{}};
let soundCtx=null,retries=0,lastLot='',toastTimer,matchCanvas=null;
const player=id=>app.byId.get(id)||{id,name:'Loading footballer',position:'—',secondary:[],rating:'—',basePrice:0,attributes:{ATT:0,MID:0,DEF:0,GK:0},image:'/assets/fallback.svg'};
// If a Wikimedia thumbnail is temporarily unavailable, try that footballer's
// original source image once before falling back to their own illustrated card.
// Mapping is by immutable player ID/catalog URL, never by a guessed picture name.
window.playerPhotoError=(img)=>{
 const src=img.getAttribute('src');
 if(img.dataset.triedOriginal!=='1'){
  img.dataset.triedOriginal='1';
  const known=app.catalog.find(p=>p.image===src||p.imageThumb===src);
  const original=img.dataset.photoOriginal||known?.imageOriginal;
  if(original&&original!==src){img.src=original;return;}
 }
 img.onerror=null;
 img.src=img.dataset.fallback||'/assets/fallback.svg';
};
const me=()=>app.room?.managers.find(m=>m.id===app.myId);
const team=id=>app.room?.managers.find(m=>m.id===id);
const money=n=>(Number(n)||0).toLocaleString('en-IN');
const timeLabel=t=>new Date(t).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
const getMs=deadline=>Math.max(0,(deadline||0)-(Date.now()+app.serverOffset));
const remaining=deadline=>{const sec=Math.ceil(getMs(deadline)/1000);return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`;};
function ding(type='ok'){if(!app.sound)return;try{soundCtx??=new (window.AudioContext||window.webkitAudioContext)();const osc=soundCtx.createOscillator(),gain=soundCtx.createGain();osc.type='sine';osc.frequency.setValueAtTime(type==='error'?190:680,soundCtx.currentTime);gain.gain.setValueAtTime(.045,soundCtx.currentTime);gain.gain.exponentialRampToValueAtTime(.0001,soundCtx.currentTime+.15);osc.connect(gain);gain.connect(soundCtx.destination);osc.start();osc.stop(soundCtx.currentTime+.15);}catch{}}
let lastToast={text:'',at:0};
function showToast(message,kind='info',duration=4200){
 const node=$('#toast'),time=Date.now();
 if(lastToast.text===message&&time-lastToast.at<1200)return;
 lastToast={text:message,at:time};node.hidden=false;node.className=`toast ${kind}`;
 node.innerHTML=`<span class="toast-indicator" aria-hidden="true">${kind==='error'?'!':kind==='success'?'✓':'•'}</span><span>${esc(message)}</span><button type="button" class="toast-dismiss" data-action="dismissToast" aria-label="Dismiss notification">×</button>`;
 clearTimeout(toastTimer);toastTimer=setTimeout(()=>{node.hidden=true},duration);ding(kind==='error'?'error':'ok');
}
function announceRoomChanges(previous,current){
 if(!previous)return;
 const before=new Set((previous.log||[]).map(e=>`${e.at}-${e.text}`));
 const important=(current.log||[]).filter(e=>!before.has(`${e.at}-${e.text}`)&&/DEAL COMPLETE|random|joins|won|sold|unsold|squad complete|champion/i.test(e.text));
 if(important.length&&app.view!=='arena')showToast(important.at(-1).text,'event');
 if(previous.stage!==current.stage){
  const messages={auction:'NEW AUCTION — Make your next bid.',transfer:'THE MARKET IS OPEN — Make your trades.',final:'FINAL MARKET — Last chance to trade.',swap:'SURPRISE SWAP INCOMING.',lineup:'SET YOUR XI — Confirm your formation.',halftime:'HALFTIME — Make your tactical changes.',match:'KICK-OFF — Watch the match.',done:'TOURNAMENT COMPLETE — See the results.'};
  if(messages[current.stage]&&app.view!=='arena')showToast(messages[current.stage],'event',5500);
 }
}
function processArenaEvents(previous,current){
 if(!current)return;
 const all=current.events||[],key=current.code;
 if(!app.seenEvents||app.seenEvents.room!==key){app.seenEvents={room:key,ids:new Set(all.map(x=>x.id))};return;}
 const newEvents=all.filter(x=>!app.seenEvents.ids.has(x.id));
 all.forEach(x=>app.seenEvents.ids.add(x.id));
 // Do not replay event history after a refresh, nor create a stack of popups.
 const event=newEvents.at(-1);if(!event||app.view!=='arena'||!['auction','transfer','final'].includes(current.stage))return;
 const node=$('#arenaEvent');if(!node)return;
 let heading='',details='',portraits='';
 if(event.type==='marketOpen'){heading='TRANSFER WINDOW '+(event.ordinal===1?'I':'II');details=event.ordinal===1?'THE MARKET IS OPEN — make your move.':'FINAL TRANSFER SHOWDOWN — your last deals.';}else if(event.type==='signed'){
  const p=player(event.cardId);heading='PLAYER SIGNED';details=`${esc(p.name)} joins ${esc(team(event.teamId)?.team)} · ${money(event.credits)} credits`;
  portraits=smallPortrait(p);
 }else if(event.type==='tradeIncoming'){
  heading='TRANSFER INCOMING';details=`${esc(team(event.from)?.team)} ↔ ${esc(team(event.to)?.team)} · approval needed`;
  portraits=[event.giveId,event.wantId].filter(Boolean).map(id=>smallPortrait(player(id))).join('');
 }else if(event.type==='tradeDone'){
  heading='TRANSFER COMPLETE';details=`${esc(team(event.from)?.team)} ↔ ${esc(team(event.to)?.team)}`;
  portraits=[event.giveId,event.wantId].filter(Boolean).map(id=>smallPortrait(player(id))).join('');
 }else return;
 node.innerHTML=`<div class="arena-pop-photos">${portraits}</div><div><strong>${heading}</strong><p>${details}</p></div><button class="arena-pop-close" data-action="closeArenaPop" aria-label="Dismiss event">×</button>`;
 node.hidden=false;clearTimeout(app.arenaPopupTimer);app.arenaPopupTimer=setTimeout(()=>node.hidden=true,4700);
}
function showActionAlerts(){
 const node=$('#actionAlerts');if(!node)return;
 const r=app.room,m=me();
 const pending=r&&m&&['transfer','final'].includes(r.stage)?r.offers.filter(o=>o.to===m.id&&o.status==='pending'):[];
 node.innerHTML=pending.length?`<div class="action-alert"><div><strong>TRADE REQUEST${pending.length>1?'S':''}</strong><small>${pending.length} awaiting your response</small></div><button class="btn btn-sm btn-primary" data-action="goOffers">REVIEW ↗</button></div>`:'';
}

function send(type,payload={}){if(app.socket?.readyState!==1){showToast('Connection is not ready. Your action was not sent.');return;}app.socket.send(JSON.stringify({type,payload}));}
function connect(){
 const url=`${location.protocol==='https:'?'wss':'ws'}://${location.host}`;
 const ws=new WebSocket(url);app.socket=ws;
 ws.addEventListener('open',()=>{app.connected=true;retries=0;net();});
 ws.addEventListener('message',e=>{let data;try{data=JSON.parse(e.data)}catch{return;}
  if(data.type==='connected'){const saved=JSON.parse(localStorage.getItem('far-session')||'null');if(saved?.code&&saved?.token)send('join',{code:saved.code,token:saved.token,name:saved.name||'Manager'});return;}
  if(data.type==='identity'){app.myId=data.id;if(data.code&&data.token){localStorage.setItem('far-session',JSON.stringify({code:data.code,token:data.token,name:me()?.name||''}));}return;}
  if(data.type==='state'){const previous=app.room,prev=app.room?.stage;app.room=data.room;
   if(app.clubFocus && !data.room.managers.some(x=>x.id===app.clubFocus))app.clubFocus=null;
   if(previous && previous.code===data.room.code){for(const club of data.room.managers){const old=previous.managers.find(x=>x.id===club.id);if(old&&old.credits!==club.credits)app.creditEffects[club.id]={delta:club.credits-old.credits,until:Date.now()+2200};}}
   if(app.pendingShape && data.room.managers.find(x=>x.id===app.myId)?.formation===app.pendingShape)app.pendingShape=null;
   if(app.movePending && app.pendingLineup && data.room.managers.find(x=>x.id===app.myId)?.lineup?.join('|')===app.pendingLineup.join('|')){app.movePending=false;app.pendingLineup=null;app.moveSource=null;}
   announceRoomChanges(previous,data.room);processArenaEvents(previous,data.room);
   if(app.tradePending&&data.room.offers.some(o=>o.from===app.myId&&o.to===app.tradeTo&&o.giveId===app.giveId&&o.wantId===app.wantId)){app.tradePending=false;app.tradeModal=false;app.giveId='';app.wantId='';showToast('Trade offer sent — waiting for approval.','success');}
   if(app.room?.auction?.id!==lastLot){lastLot=app.room?.auction?.id||'';app.bidDraft='';}
   if(prev!==app.room.stage){app.moveSource=null;app.movePending=false;app.pendingLineup=null;app.pendingShape=null;app.editMode=false;app.squadViewer=null;app.giveId='';app.wantId='';app.tradeTo='';app.tradeModal=false;app.tradePending=false;app.auctionWarned='';}
   if(previous?.stage==='match'&&data.room.stage==='match'&&previous.match?.id===data.room.match?.id&&previous.match?.half===data.room.match?.half&&updateMatchOnly())return;
   if(previous?.stage==='auction'&&app.room.stage==='auction'&&previous.auction?.id===app.room.auction?.id&&JSON.stringify(previous.managers.map(m=>[m.squad,m.lineup,m.credits,m.ready]))===JSON.stringify(app.room.managers.map(m=>[m.squad,m.lineup,m.credits,m.ready]))&&updateBidOnly())return;
   render();return;}
  if(data.type==='clock'){app.serverOffset=data.serverTime-Date.now();renderClock();return;}
  if(data.type==='imageUpdated'){const p=app.byId.get(data.id);if(p){p.image=data.image;p.imageThumb=data.image;p.imageOriginal=data.image;p.imageStatus='host_uploaded';p.reviewRequired=false;render();}return;}
  if(data.type==='error'){app.tradePending=false;app.movePending=false;app.pendingLineup=null;app.moveSource=null;render();if(data.message==='Room not found'||data.message==='Game has already started'){localStorage.removeItem('far-session');}showToast(data.message,'error');return;}
 });
 ws.addEventListener('close',()=>{app.connected=false;net();setTimeout(connect,Math.min(8000,700*Math.pow(1.6,retries++)));});
 ws.addEventListener('error',()=>{app.connected=false;net();});
}
function net(){const n=$('#net');n.className='status-chip '+(app.connected?'online':'offline');n.innerHTML=`<i></i> ${app.connected?'Live connection':'Offline / reconnecting'}`;}
async function loadCatalog(){try{const r=await fetch('/api/catalog');if(!r.ok)throw Error();app.catalog=await r.json();app.byId=new Map(app.catalog.map(p=>[p.id,p]));render();}catch{showToast('Unable to load footballer catalog. Refresh when connected.');}}
function card(p,cls=''){return `<article class="player-card ${cls}" aria-label="Collectible card for ${esc(p.name)}">
 <img class="card-art" src="${esc(p.image||'/api/art/'+p.id+'.svg')}" alt="Portrait or illustrated card artwork for ${esc(p.name)}" data-fallback="${esc(p.imageFallback||'/api/art/'+p.id+'.svg')}" loading="lazy" onerror="window.playerPhotoError(this)">
 <div class="card-top">${p.rating}<small>OVR</small></div>
 <div class="card-content"><div class="card-name">${esc(p.name)}</div><div class="card-meta"><span>${esc(p.position)}</span><span>PRIME ERA</span>${p.perk?`<span style="color:var(--accent)">${esc(p.perk)}</span>`:''}</div><div class="attributes">${['ATT','MID','DEF','GK'].map(k=>`<div><strong>${p.attributes?.[k]??'—'}</strong><small>${k}</small></div>`).join('')}</div><div class="card-foot">ROYALE // EXCLUSIVE PRIME SERIES</div></div></article>`;}
function title(k,title,aside=''){return `<div class="section-title"><small>${k}</small><h2>${title}</h2>${aside?`<div style="margin-left:auto">${aside}</div>`:''}</div>`;}
function managerRows(){return `<div class="stack" style="gap:0">${(app.room?.managers||[]).map(m=>`<div class="manager-row"><div class="color" style="background:${esc(m.color)}"></div><div><strong>${esc(m.team)} ${m.id===app.myId?'<span class="accent">(YOU)</span>':''}</strong><small>${m.human?(m.online?'● ONLINE':m.aiControl?'● AI TAKEOVER':'○ RECONNECTING'):'◇ AI '+app.room.settings.difficulty} · ${m.squad.length}/16 players</small><div class="progress-bar"><span style="width:${m.squad.length/16*100}%"></span></div></div><span class="money">${money(m.credits)}</span></div>`).join('')}</div>`;}
function timeline(limit=9){return `<ul class="activity">${(app.room?.log||[]).slice(-limit).reverse().map(e=>`<li><time>${timeLabel(e.at)}</time>${esc(e.text)}</li>`).join('')||'<li>Match activity will appear here.</li>'}</ul>`;}
const isHost=()=>!!app.room&&app.myId===app.room.hostId;
function headerRoom(){if(!app.room)return '';
 const r=app.room;return `<div class="space-between" style="margin-bottom:23px;flex-wrap:wrap"><div><div class="eyebrow">LIVE GAME // ${esc(r.title)} </div><h2 style="margin:6px 0 0">${({lobby:'THE DRESSING ROOM',auction:'THE AUCTION ARENA',transfer:'THE TRANSFER DESK',swap:'RANDOM SWAP',final:'THE FINAL MARKET',lineup:'SET YOUR STARTING XI',match:'MATCHDAY LIVE',halftime:'HALFTIME TACTICS',done:'CHAMPIONSHIP RESULTS'})[r.stage]||'TOURNAMENT'}</h2></div><div class="btn-row">${r.stage!=='lobby'&&!['auction','transfer','final','match','halftime'].includes(r.stage)?`<button class="btn btn-sm btn-secondary" data-action="viewSquad">VIEW FORMATIONS ↗</button>`:''}<span class="tag">ROOM ${esc(r.code)}</span><button class="btn btn-sm btn-ghost" data-action="copyCode">COPY CODE</button><button class="btn btn-sm btn-ghost" data-action="copyLink">COPY INVITE</button></div></div>`;}
function welcome(){return `<section class="hero animate-in"><div><div class="eyebrow">THE BEAUTIFUL GAME. THE ULTIMATE AUCTION.</div><h1>BUILD YOUR <span>LEGACY.</span></h1><p class="lead">A thousand prime-era footballers. One card at a time. Bid like a master, build an unstoppable sixteen, and watch your squad fight for the crown.</p><div class="welcome-form"><h3>ENTER THE ARENA</h3><p class="muted small">Host a private game or join your friends from any browser.</p><form id="createForm"><div class="field"><label for="createName">Your manager name</label><input id="createName" name="name" placeholder="Your name" maxlength="40" required value="Manager"></div><div class="field-row"><div class="field"><label for="humans">Human managers (1–8)</label><select id="humans" name="humans">${Array.from({length:8},(_,i)=>`<option value="${i+1}">${i+1}</option>`).join('')}</select></div><div class="field"><label for="bots">AI opponents (0–7)</label><select id="bots" name="bots">${Array.from({length:8},(_,i)=>`<option value="${i}" ${i===3?'selected':''}>${i}</option>`).join('')}</select></div></div><div class="field-row"><div class="field"><label for="difficulty">AI difficulty</label><select id="difficulty" name="difficulty"><option>Easy</option><option selected>Normal</option><option>Expert</option></select></div><div class="field"><label for="createTeam">Team name</label><input id="createTeam" name="team" maxlength="40" placeholder="Your dream club"></div></div><p class="micro" id="budgetPreview">1 human · 3 AI · 1,700 credits per team</p><button class="btn btn-primary full" type="submit">CREATE PRIVATE GAME <span aria-hidden="true">↗</span></button></form><hr class="sep"><form id="joinForm" class="join-line"><div class="field"><label for="joinName">Your name</label><input id="joinName" name="name" placeholder="Manager" maxlength="40" required></div><div class="field"><label for="joinCode">Room code</label><input id="joinCode" name="code" placeholder="ABC123" maxlength="6" value="${esc(new URLSearchParams(location.search).get('room')||'')}" required style="text-transform:uppercase"></div><button class="btn btn-secondary" type="submit">JOIN ROOM</button></form></div><div class="metrics"><div class="metric"><strong>1,000</strong><small>CURATED NAMES</small></div><div class="metric"><strong>16</strong><small>PER SQUAD</small></div><div class="metric"><strong>60s</strong><small>PER AUCTION</small></div></div></div><div class="hero-side"><div class="highlight-card">${card(player('FC0935'))}</div></div></section>`;}
function lobby(){const r=app.room,m=me();return `<div class="container animate-in">${headerRoom()}<div class="layout-left"><div class="panel"><div class="panel-head"><h3>MANAGERS ASSEMBLE</h3><span class="tag">${r.managers.filter(x=>x.human).length} / ${r.settings.humans} HUMANS</span></div>${managerRows()}<hr class="sep"><div class="field-row"><div class="field"><label>Display name</label><input id="nameEdit" maxlength="40" value="${esc(m?.name||'')}"></div><div class="field"><label>Team name</label><input id="teamEdit" maxlength="40" value="${esc(m?.team||'')}"></div></div><div class="btn-row"><button class="btn btn-sm" data-action="saveName">SAVE IDENTITY</button><button class="btn ${m?.ready?'btn-secondary':'btn-primary'}" data-action="toggleReady">${m?.ready?'✓ READY — UNREADY':'MARK READY'}</button>${m?.id===r.hostId?`<button class="btn btn-primary" data-action="start">START AUCTION ↗</button>`:''}<button class="btn btn-ghost btn-sm" data-action="leave">LEAVE ROOM</button></div><p class="small muted" style="margin-top:16px">All configured human slots must be filled and ready. Bots are added only when the host starts.</p></div><div class="stack"><section class="panel"><h3>ROOM CONTRACT</h3>${m?.id===r.hostId?`<div class="field-row"><div class="field"><label for="hostHumans">Human slots</label><select id="hostHumans">${Array.from({length:8},(_,i)=>`<option ${i+1===r.settings.humans?'selected':''}>${i+1}</option>`).join('')}</select></div><div class="field"><label for="hostBots">AI opponents</label><select id="hostBots">${Array.from({length:9-r.settings.humans},(_,i)=>`<option ${i===r.settings.bots?'selected':''}>${i}</option>`).join('')}</select></div></div><div class="field"><label for="hostDifficulty">AI difficulty</label><select id="hostDifficulty">${['Easy','Normal','Expert'].map(v=>`<option ${v===r.settings.difficulty?'selected':''}>${v}</option>`).join('')}</select></div><button class="btn btn-sm btn-secondary" data-action="hostConfig">SAVE ROOM SETTINGS</button><hr class="sep">`:''}<div class="stats-grid"><div class="stat-box"><strong>${money(1700+150*(r.settings.humans-1))}</strong><small>CREDITS / TEAM</small></div><div class="stat-box"><strong>${r.settings.bots}</strong><small>AI OPPONENTS</small></div><div class="stat-box"><strong>${r.settings.difficulty}</strong><small>AI DIFFICULTY</small></div></div><hr class="sep"><p class="micro">AUCTION 60s • 10-credit increases • ANTI-SNIPE +5s</p><p class="micro">TWO TRANSFER WINDOWS • AFTER 6× AND 11× COMPLETED AUCTIONS • 300s EACH</p><p class="micro">11 STARTERS • 5 SUBSTITUTES • MAXIMUM 5 HALFTIME CHANGES</p></section><div class="panel"><h3>INVITE YOUR RIVALS</h3><p class="muted small">Friends can join from other devices on the same reachable server. The room code identifies the game, not your private manager identity.</p><button class="btn btn-secondary" data-action="copyLink">COPY INVITATION LINK ↗</button></div></div></div></div>`;}
// A compact pitch uses the existing ID-based image mapping. These are the
// same real player records as auctions, trades and match lineups.
function miniPitch(m,small=false){
 const lineup=slotsFor(m),bench=m.squad.filter(id=>!lineup.includes(id));
 const node=i=>{const id=lineup[i],pos=slotDisplayName(m.formation,i);if(!id)return `<span class="arena-empty-player" title="Empty ${esc(pos)} slot"><b>+</b><small>${esc(pos)}</small></span>`;
  const p=player(id),short=p.name.split(/\s+/).slice(-1)[0];
  return `<button class="arena-pitch-player" data-action="inspect" data-id="${esc(id)}" title="${esc(p.name)} · ${esc(pos)}" aria-label="Inspect ${esc(p.name)} of ${esc(m.team)}, playing ${esc(pos)}"><img src="${esc(p.image||'/assets/fallback.svg')}" data-fallback="${esc(p.imageFallback||'/api/art/'+p.id+'.svg')}" alt="" loading="lazy" decoding="async" onerror="window.playerPhotoError(this)"><strong>${esc(short)}</strong><small>${esc(pos)}</small></button>`;
 };
 return `<article class="arena-team ${m.id===app.myId?'arena-own-team':''} ${small?'arena-team-small':''}" style="--team-color:${esc(m.color)}" aria-label="${esc(m.team)} formation">
 <div class="arena-team-head"><span class="arena-team-dot"></span><strong title="${esc(m.team)}">${esc(m.id===app.myId?'MY TEAM · '+m.team:m.team)}</strong><span>${m.squad.length}/16</span></div>
 <div class="arena-team-sub"><span>${esc(m.formation||'4-3-3')}</span><span>${Number.isInteger(m.draftWins)?m.draftWins:m.squad.length} DRAFTED</span></div>
 <div class="arena-mini-pitch" aria-label="Starting eleven">${shapeOf(m).rows.map(group=>`<div class="arena-mini-row">${group.map(node).join('')}</div>`).join('')}</div>
 <div class="arena-team-bench"><span>BENCH</span><div>${bench.map(id=>`<button class="arena-bench-face" data-action="inspect" data-id="${esc(id)}" aria-label="Inspect ${esc(player(id).name)}" title="${esc(player(id).name)}"><img src="${esc(player(id).imageThumb||player(id).image)}" data-fallback="${esc(player(id).imageFallback||'/api/art/'+id+'.svg')}" alt="" loading="lazy" decoding="async" onerror="window.playerPhotoError(this)"></button>`).join('')}${Array.from({length:Math.max(0,5-bench.length)},()=>'<span class="arena-bench-empty">·</span>').join('')}</div></div>
 </article>`;
}
function arenaTeams(mode='rail'){
 const list=app.room?.managers||[];
 if(mode==='strip')return `<section class="arena-formation-strip" aria-label="Every manager's live football formation"><div class="arena-strip-title"><strong>ALL TEAMS LIVE</strong><small>Tap any player to inspect</small></div><div class="arena-team-grid compact" style="--team-columns:${Math.max(1,list.length)}">${list.map(m=>miniPitch(m,true)).join('')}</div></section>`;
 const cut=Math.ceil(list.length/2);
 return {left:list.slice(0,cut).map(m=>miniPitch(m)).join(''),right:list.slice(cut).map(m=>miniPitch(m)).join('')};
}
// Live prominent club strip + permission-aware, click / drag tactical pitch.
function clubBar(){
 const r=app.room;if(!r)return '';
 return `<section class="club-switcher" aria-label="Switch football clubs"><button type="button" class="club-my-button" data-action="clubView" data-id="${esc(app.myId)}">⌂ MY CLUB</button><div class="club-strip">${r.managers.map(m=>`<button type="button" data-action="clubView" data-id="${esc(m.id)}" class="club-pill ${app.clubFocus===m.id?'club-selected':''}" style="--team-color:${esc(m.color)}" aria-pressed="${app.clubFocus===m.id}"><i></i><span><b>${esc(m.team)}</b><small>${esc(m.name)} · ${m.squad.length}/16</small></span></button>`).join('')}</div></section>`;
}
function clubBoard(){
 if(!app.clubFocus||!app.room)return '';
 const m=team(app.clubFocus);if(!m)return '';
 const own=m.id===app.myId;
 const canEdit=own&&['auction','transfer','final','lineup'].includes(app.room.stage)&&!(app.room.stage==='lineup'&&m.ready);
 const canHalf=own&&app.room.stage==='halftime'&&app.room.match?.teams.includes(m.id)&&!app.room.match.halftimeReady.includes(m.id);
 const editable=canEdit||canHalf;
 const lineup=slotsFor(m), bench=m.squad.filter(id=>!lineup.includes(id));
 const selected=app.moveSource;
 const selectedPlayer=selected==null?null:(selected<11?lineup[selected]:bench[selected-11]);
 const slot=(index,id,benchSlot=false)=>{
  const p=id?player(id):null;
  const rating=p?.positionRatings?.[slotNames(m)[index]]??p?.rating??0;
  const projected=selectedPlayer?player(selectedPlayer)?.positionRatings?.[slotNames(m)[index]]:null;
  const action=editable?'data-action="formationSlot"':'';
  const attrs=`data-slot="${benchSlot?11+index:index}" ${action} ${editable&&id?'draggable="true"':''}`;
  return `<button type="button" class="club-slot ${selected===(benchSlot?11+index:index)?'club-slot-selected':''} ${id?'':'club-slot-empty'}" ${attrs} ${editable?'':'data-action="inspect" data-id="'+esc(id||'')+'"'} aria-label="${esc(id?p.name:'Empty '+(benchSlot?'bench':slotDisplayName(m.formation,index))+' position')}" title="${esc(id?p.name:'Empty slot')} ${esc(id?'· '+rating+' effective OVR':'')}">
  ${p?`<img src="${esc(p.image)}" data-fallback="${esc(p.imageFallback||'/api/art/'+p.id+'.svg')}" alt="" loading="lazy" decoding="async" onerror="window.playerPhotoError(this)"><strong>${esc(p.name.split(' ').slice(-1)[0])}</strong>`:'<span class="club-slot-plus">+</span>'}
  <small>${esc(benchSlot?'SUB':slotDisplayName(m.formation,index))} ${id?`· <b class="${rating<=45?'bad':rating<p.rating-14?'poor':rating<p.rating-6?'fair':'good'}">${rating}</b>`:''}${!benchSlot&&projected!=null?`<em>→${projected}</em>`:''}</small></button>`;
 };
 const rows=shapeOf(m).rows;
 return `<section class="club-focus panel" aria-label="${esc(m.team)} tactical formation"><div class="club-focus-head"><div><span class="eyebrow">${own?'YOUR TACTICAL BOARD':'RIVAL CLUB / VIEW ONLY'}</span><h3>${esc(m.team)} <small>· ${m.squad.length}/16 · ${lineup.filter(Boolean).length}/11 starters</small></h3></div><div class="club-focus-controls">${canEdit?'<button class="btn btn-sm btn-secondary" data-action="undoFormation">UNDO CHANGE</button>':''}<button class="btn btn-sm" data-action="clubClose">CLOSE ✕</button></div></div>
 <p class="micro club-edit-hint">${editable?'Click or drag an owned player, then choose a pitch or bench slot. Ratings preview at each position.':'Inspect this club. Only its actual manager can move its players.'} ${selected!=null&&selectedPlayer?`<strong>SELECTED: ${esc(player(selectedPlayer).name)}</strong>`:''}</p>
 <div class="club-board-body"><div class="club-big-pitch">${rows.map(row=>`<div class="club-big-row">${row.map(i=>slot(i,lineup[i])).join('')}</div>`).join('')}</div><div class="club-bench-group"><strong>SUBSTITUTES · ${bench.length}/5</strong><div class="club-bench-list">${Array.from({length:Math.max(5,bench.length)},(_,i)=>slot(i,bench[i]||null,true)).join('')}</div></div></div>
 <p class="club-strength">TEAM EFFECTIVE XI <strong>${lineup.filter(Boolean).length?Math.round(lineup.reduce((sum,id,i)=>sum+(id?player(id).positionRatings?.[slotNames(m)[i]]||player(id).rating:0),0)/Math.max(1,lineup.filter(Boolean).length)):'—'}</strong> <span>· Base ratings never change. Position penalties affect matches.</span></p></section>`;
}
function moveFormation(destination){
 const m=me(),r=app.room;if(!m||!r||app.movePending)return;
 const active=['lobby','auction','transfer','lineup','match','halftime'].includes(r.stage);
 if(!active)return showToast('Editing is unavailable after the game ends.','warning');
 const duringMatch=['match','halftime'].includes(r.stage);
 const halftime=r.stage==='halftime'&&r.match?.teams.includes(m.id)&&!r.match.halftimeReady.includes(m.id);
 const current=(app.pendingLineup||slotsFor(m)).slice(),bench=m.squad.filter(id=>!current.includes(id));
 const src=app.moveSource;if(src==null||src===destination){app.moveSource=null;render();return;}
 const fromId=src<11?current[src]:bench[src-11];if(!fromId){app.moveSource=null;render();return;}
 // The normal formation editor NEVER performs a substitution after kick-off.
 // A separate 'sub' action is available only at halftime.
 if(duringMatch&&(src>=11||destination>=11))return showToast('Bench substitutions are halftime-only. Use the substitutions panel.','warning');
 const next=current.slice();
 if(destination<11){
  if(src<11){[next[src],next[destination]]=[next[destination],next[src]];}
  else next[destination]=fromId;
 }else if(src<11){
  if(destination-11<bench.length)next[src]=bench[destination-11];
  else next[src]=null;
 }else{app.moveSource=null;render();return;}
 app.lastFormation=current.slice();app.lastShape=m.formation;app.movePending=true;app.moveSource=null;app.pendingLineup=next.slice();
 send('formation',{lineup:next,shape:app.pendingShape||m.formation||'4-3-3'});render();setTimeout(()=>{if(app.movePending){app.movePending=false;app.pendingLineup=null;render();}},1800);
}
// Exactly one visible live pitch per team. All interaction modes share this single component.
function fieldFormation(m,mode){
 const mine=m.id===app.myId,editing=mine&&app.editMode;
 const lineup=(mine&&app.pendingLineup?app.pendingLineup:slotsFor(m)).slice();
 const bench=m.squad.filter(id=>!lineup.includes(id));
 const chosenSrc=editing&&app.moveSource!=null?(app.moveSource<11?lineup[app.moveSource]:bench[app.moveSource-11]):null;
 const selectedForTrade=mode==='transfer'?(mine?app.giveId:app.wantId):null;
 const cardAt=(id,i,isBench=false)=>{
  const index=isBench?11+i:i,pos=isBench?'SUB':slotNames(m)[i],p=id?player(id):null;
  const base=Number(p?.rating||0),effective=!isBench?ratingAt(p,pos):base;
  const projected=chosenSrc&&!isBench?ratingAt(player(chosenSrc),pos):null;
  const selectable=editing||(mode==='transfer'&&!!id);
  const selected=editing&&app.moveSource===index||selectedForTrade===id&&!!id;
  const label=id?`${p.name} · ${pos} · ${effective} overall`:`Empty ${pos}`;
  return `<button type="button" class="field-slot ${id?'field-occupied':'field-empty'} ${selected?'field-selected':''} ${projected!=null?'field-target':''}"
  data-action="${selectable?'fieldSlot':id?'inspect':'fieldTeam'}" data-team="${esc(m.id)}" data-slot="${index}" data-id="${esc(id||'')}" ${id&&editing?'draggable="true"':''}
  ${id?'data-field-player="'+esc(m.id+':'+id)+'"':''} aria-label="${esc(label)}" aria-pressed="${selected?'true':'false'}" title="${esc(label)}">
  ${p?`<img class="field-face" src="${esc(p.imageThumb||p.image||p.imageFallback)}" data-fallback="${esc(p.imageFallback||'/api/art/'+id+'.svg')}" loading="lazy" decoding="async" alt="" onerror="window.playerPhotoError(this)"><span class="field-player-name">${esc(p.name.split(/\s+/).slice(-1)[0])}</span>`:`<span class="field-plus">+</span>`}
  <span class="field-role">${esc(pos)}${p?` · <b class="${effective<base-15?'field-poor':effective<base-6?'field-fair':'field-good'}">${effective}</b>`:''}${projected!=null?` <em>→${projected}</em>`:''}</span></button>`;
 };
 const rows=shapeOf(m).rows;
 const selected=app.clubFocus===m.id;
 return `<article class="field-team ${mine?'field-mine':''} ${selected?'field-focused':''}" data-field-team="${esc(m.id)}" style="--team-color:${esc(m.color)}" aria-label="${esc(m.team)} live formation">
 <header class="field-team-head"><button type="button" class="field-team-name" data-action="fieldTeam" data-team="${esc(m.id)}" title="Focus on ${esc(m.team)}"><span class="field-team-color"></span><span><strong>${esc(mine?'MY CLUB · '+m.team:m.team)}</strong><small>${esc(m.name)} · ${m.squad.length}/16 PLAYERS</small></span></button><span class="field-team-count">${m.squad.length}<small>/16</small></span></header>
 <div class="field-credits ${app.creditEffects[m.id]?.until>Date.now()?'field-credits-changed':''}"><strong>${money(m.credits)} <small>CREDITS</small></strong>${app.creditEffects[m.id]?.until>Date.now()?`<em>${app.creditEffects[m.id].delta>0?'+':''}${money(app.creditEffects[m.id].delta)}</em>`:''}</div>
 <div class="field-tactics-head"><span>${esc(m.formation||'4-3-3')} · ${Math.round(lineup.reduce((s,id,i)=>s+(id?ratingAt(player(id),slotNames(m)[i]):0),0)/Math.max(1,lineup.filter(Boolean).length))||'—'} OVR</span>${mine?`<button class="field-mini-action" data-action="toggleFieldEdit">${app.editMode?'FINISH EDITING':'EDIT FORMATION'}</button>`:''}</div>
 ${mine&&app.editMode?`<label class="field-formation-select-label">SHAPE <select class="field-formation-select" aria-label="Select tactical formation" data-formation-select="true">${Object.keys(SHAPES).map(sh=>`<option value="${sh}" ${sh===(app.pendingShape||m.formation||'4-3-3')?'selected':''}>${sh}</option>`).join('')}</select></label>`:''}
 <div class="field-pitch" aria-label="${esc(m.team)} pitch"><div class="field-pitch-markings"></div>${rows.map(row=>`<div class="field-row">${row.map(i=>cardAt(lineup[i],i)).join('')}</div>`).join('')}</div>
 <div class="field-bench"><span>BENCH <small>${bench.length}/5</small></span><div class="field-bench-list">${Array.from({length:5},(_,i)=>cardAt(bench[i]||null,i,true)).join('')}</div></div>
 ${mine&&app.editMode?`<div class="field-team-footer"><span>${chosenSrc?`MOVE ${esc(player(chosenSrc).name)} → CHOOSE A SLOT`:'TAP YOUR PLAYER, THEN A SLOT'}</span><button data-action="undoFormation" class="field-mini-action" ${!app.lastFormation?'disabled':''}>UNDO</button></div>`:''}
 
 </article>`;
}
function fieldOverview(mode){
 const r=app.room,m=me();if(!r)return '';
 const list=[m,...r.managers.filter(x=>x.id!==m?.id)].filter(Boolean);
 const focus=app.clubFocus&&team(app.clubFocus);
 return `<section class="field-stage" aria-label="Live formations of all managers"><div class="field-stage-heading"><div><div class="eyebrow">EVERY CLUB · LIVE ON EVERY SCREEN</div><h3>THE FORMATIONS <small>${r.managers.length} CLUBS · ONE PITCH EACH</small></h3></div><div class="field-toolbar"><button class="btn btn-sm ${app.clubFocus===app.myId?'btn-primary':'btn-secondary'}" data-action="fieldMyClub">MY CLUB ↗</button>${mode==='transfer'?`<button class="btn btn-sm ${app.editMode?'btn-primary':'btn-secondary'}" data-action="toggleFieldEdit">${app.editMode?'✓ FINISH EDITING':'EDIT MY POSITIONS'}</button>`:''}</div></div>
 ${mode==='transfer'?`<p class="field-instruction">${app.editMode?'Editing your team · tap a player, then its new position. Other teams can watch the changes.':app.giveId?`<strong>${esc(player(app.giveId).name)}</strong> selected · now choose a footballer on another pitch.`:'Trade players: tap yours, then tap theirs. Both managers approve before a swap.'}</p>`:`<p class="field-instruction">${app.moveSource!=null?'Player selected — tap a destination on your pitch.':'Click EDIT FORMATION on your own pitch to change the shape or move players. Everyone sees saved changes.'}</p>`}
 <div class="field-grid" style="--count:${r.managers.length}">${list.map(x=>fieldFormation(x,mode)).join('')}</div>
 ${mode==='auction'?`<p class="field-help">All squads update live when a footballer is signed. Tap a rival player to inspect their card.</p>`:''}
 </section>`;
}
function auction(){
 const r=app.room,a=r.auction,p=player(a.cardId),m=me(),minimum=a.highestBid?a.highestBid+10:10;
 const cap=(m?.credits||0)-(16-(m?.squad.length||0)-1)*20;
 const disabled=!m||m.squad.length>=16||a.passed.includes(m.id)||minimum>cap||a.leader===m.id;
 if(!app.bidDraft||+app.bidDraft<minimum)app.bidDraft=String(minimum);
 return `<div class="container arena-live single-fields animate-in">${headerRoom()}<section class="auction-priority" aria-label="Active footballer auction"><div class="auction-artwork">${card(p,'arena-card')}</div><div class="auction-bidding"><div class="arena-bid-top"><span class="lot">LOT ${String(a.number).padStart(3,'0')} · NOW BIDDING</span><span class="arena-clock" data-clock="${a.deadline}">${remaining(a.deadline)}</span></div><h2 class="arena-player-name">${esc(p.name)}</h2><div class="arena-player-positions">${[p.position,...(p.secondary||[])].slice(0,5).map(pos=>`<span>${esc(pos)}</span>`).join('')}</div>
 <div class="arena-bid-amount"><small>${a.highestBid?'CURRENT BID':'OPENING BID'}</small><strong id="arenaBidAmount">${money(a.highestBid)}</strong></div>
 <div class="arena-highest"><span>Leading</span><strong id="arenaLeader">${esc(a.leader?team(a.leader)?.team:'No bids yet')}</strong></div>
 <form id="bidForm"><div class="arena-main-bid"><input aria-label="Your bid in credits" id="bidInput" type="number" step="10" min="${minimum}" max="${Math.max(minimum,cap)}" value="${esc(app.bidDraft)}" ${disabled?'disabled':''} required><button class="btn btn-primary" id="arenaBidButton" ${disabled?'disabled':''} type="submit">BID +10 ↗</button></div></form>
 <div class="arena-my-credits">Your credits: <strong>${money(m?.credits||0)}</strong><span id="arenaBidHint">${disabled?(m?.squad.length>=16?'Squad full':a.leader===m?.id?'You are leading':a.passed.includes(m?.id)?'You passed':'Not enough credits'):'Next bid: '+money(minimum)}</span></div>
 <div class="arena-secondary"><button class="btn btn-sm btn-ghost" data-action="pass" id="arenaPassButton" ${a.passed.includes(m?.id)||a.leader===m?.id?'disabled':''}>${a.passed.includes(m?.id)?'Passed':'Pass'}</button><button class="btn btn-sm btn-secondary" data-action="endAuction" id="arenaVoteButton" ${a.votes.includes(m?.id)?'disabled':''}>${a.votes.includes(m?.id)?'✓ Voted':'End Bidding'}</button><span class="field-votes">${a.votes.length}/${r.managers.length} voted</span></div>
 </div></section>${marketHint()}${fieldOverview('auction')}<details class="arena-history"><summary>Recent game activity</summary>${timeline(9)}</details></div>`;
}
function updateBidOnly(){
 const r=app.room,a=r?.auction,m=me();if(!a||!m||!document.querySelector('.arena-live'))return false;
 const p=player(a.cardId),minimum=a.highestBid?a.highestBid+10:10,cap=m.credits-(16-m.squad.length-1)*20;
 const disabled=m.squad.length>=16||a.passed.includes(m.id)||minimum>cap||a.leader===m.id;
 const amount=$('#arenaBidAmount'),leader=$('#arenaLeader'),input=$('#bidInput'),bid=$('#arenaBidButton');if(!amount||!leader||!input||!bid)return false;
 amount.textContent=money(a.highestBid);leader.textContent=team(a.leader)?.team||'No bids yet';
 input.min=String(minimum);input.max=String(Math.max(minimum,cap));
 if(+input.value<minimum){input.value=String(minimum);app.bidDraft=String(minimum);}
 input.disabled=disabled;bid.disabled=disabled;
 const hint=$('#arenaBidHint');if(hint)hint.textContent=disabled?(m.squad.length>=16?'Squad full':a.leader===m.id?'You are leading':a.passed.includes(m.id)?'You passed':'Not enough credits'):'Next bid: '+money(minimum);
 const pass=$('#arenaPassButton'),vote=$('#arenaVoteButton');if(pass){pass.disabled=a.passed.includes(m.id)||a.leader===m.id;pass.textContent=a.passed.includes(m.id)?'Passed':'Pass';}if(vote){vote.disabled=a.votes.includes(m.id);vote.textContent=a.votes.includes(m.id)?'✓ Voted':'End Bidding';}
 renderClock();return true;
}
function swapView(){
 const sw=app.room.swap;if(!sw)return '<div class="container">Preparing next round…</div>';
 const result=sw.result,phase=sw.phase==='warning';
 const p=result?.giveId?player(result.giveId):null,q=result?.wantId?player(result.wantId):null;
 return `<div class="container arena-swap animate-in">${headerRoom()}<section class="swap-stage" role="status" aria-live="polite">
 <div class="swap-circlet">${phase?'⚡':'⇄'}</div>
 <div class="eyebrow">TRANSFER WINDOW ${sw.windowNo} · MARKET SURPRISE</div>
 <h1>${phase?'SURPRISE SWAP<br><span>INCOMING.</span>':result?.skipped?'NO LEGAL SWAP':'SWAP <span>COMPLETE.</span>'}</h1>
 <p class="muted">${phase?'No transfer was completed during the market. One legal surprise exchange is being drawn.':result?.skipped?'No legal player exchange was available. No players or credits changed.':'Two players have exchanged teams. No credits were transferred.'}</p>
 ${!phase&&!result?.skipped?`<div class="swap-result-cards"><div>${smallPortrait(p)}<strong>${esc(p.name)}</strong><small>TO ${esc(team(result.to)?.team)}</small></div><span>⇄</span><div>${smallPortrait(q)}<strong>${esc(q.name)}</strong><small>TO ${esc(team(result.from)?.team)}</small></div></div>`:''}
 <div class="swap-countdown">${phase?'Swapping in':'Next auction in'} <strong data-clock="${sw.deadline}">${remaining(sw.deadline)}</strong></div>
 </section></div>`;
}
function tradeOptions(ids,chosen){return `<option value="">— None —</option>${ids.map(id=>`<option value="${id}" ${chosen===id?'selected':''}>${esc(player(id).name)} · ${player(id).position} · ${player(id).rating}</option>`).join('')}`;}
function transfer(){
 const r=app.room,t=r.transfer,m=me(),received=r.offers.filter(o=>o.to===m.id&&o.status==='pending');
 const other=team(app.tradeTo)||r.managers.find(x=>x.id!==m.id);
 if(other&&!app.tradeTo)app.tradeTo=other.id;
 const pair=app.giveId&&app.wantId;
 return `<div class="container animate-in arena-transfer single-fields">${headerRoom()}
 <section class="transfer-priority panel"><div class="transfer-priority-copy"><div class="eyebrow">${t.ordinal===1?'TRANSFER WINDOW I':'TRANSFER WINDOW II'}</div><h2>${t.ordinal===1?'THE MARKET IS OPEN.':'THE FINAL TRANSFER SHOWDOWN.'}</h2><p class="muted small">Tap your player, then one from another team. They must accept.</p></div><div class="transfer-priority-controls"><div class="transfer-timer"><span>TIME LEFT</span><strong class="timer" data-clock="${t.deadline}">${remaining(t.deadline)}</strong></div><button class="btn btn-sm btn-secondary" data-action="endTransfers" ${t.votes.includes(m.id)?'disabled':''}>${t.votes.includes(m.id)?'✓ VOTED':'END TRANSFERS'}</button><span class="field-votes">${t.votes.length}/${r.managers.length} voted</span></div></section>
 <div class="market-grand-sub">FIVE MINUTES. EVERY CLUB. MAKE YOUR MOVE.</div>${fieldOverview('transfer')}
 ${pair?`<section class="field-trade-choice panel"><div class="field-trade-choice-info"><div>${smallPortrait(player(app.giveId))}<strong>${esc(player(app.giveId).name)}</strong></div><span class="trade-arrow">⇄</span><div>${smallPortrait(player(app.wantId))}<strong>${esc(player(app.wantId).name)}</strong></div></div><button class="btn btn-primary" data-action="reviewTrade">PROPOSE THIS SWAP ↗</button><button class="btn btn-sm btn-ghost" data-action="clearFieldTrade">CHANGE SELECTION</button></section>`:app.giveId?`<div class="field-trade-choice field-waiting">Giving ${esc(player(app.giveId).name)} · tap a rival footballer next. <button class="btn btn-sm" data-action="clearFieldTrade">CANCEL</button></div>`:''}
 ${received.length?`<section class="panel field-incoming" id="offersArea"><div class="panel-head"><h3>TRADE REQUESTS FOR YOU</h3><span class="tag">${received.length} PENDING</span></div>${received.map(o=>offerCard(o,true)).join('')}</section>`:''}
 <details class="trade-advanced"><summary>More options · credits & one-sided transfers</summary><section class="panel"><form id="offerForm"><div class="field"><label for="tradeTo">Trade with</label><select id="tradeTo">${r.managers.filter(x=>x.id!==m.id).map(x=>`<option value="${x.id}" ${other?.id===x.id?'selected':''}>${esc(x.team)}</option>`).join('')}</select></div><div class="field-row"><div class="field"><label for="giveId">Your footballer</label><select id="giveId">${tradeOptions(m.squad,app.giveId)}</select></div><div class="field"><label for="wantId">Their footballer</label><select id="wantId">${tradeOptions(other?.squad||[],app.wantId)}</select></div></div><div class="field"><label for="cash">Credits pay (+) / receive (−)</label><input id="cash" type="number" step="10" value="${esc(app.cash)}"></div><button class="btn btn-secondary btn-sm" type="submit">SEND ADVANCED OFFER</button></form></section></details>
 <details class="trade-history"><summary>Previous offers (${r.offers.length})</summary><section class="panel">${r.offers.slice(-8).reverse().map(o=>offerCard(o,false)).join('')||'<p class="muted small">No trades proposed yet.</p>'}<hr class="sep">${timeline(5)}</section></details>
 </div>`;
}
function offerCard(o,incoming){
 const from=team(o.from),to=team(o.to),p1=o.giveId?player(o.giveId):null,p2=o.wantId?player(o.wantId):null;
 return `<div class="transfer-card offer-visual"><div class="offer-line"><strong class="small">${esc(from?.team)} → ${esc(to?.team)}</strong><span class="tag ${o.status==='accepted'?'':'blue'}">${esc(o.status.toUpperCase())}</span></div><div class="trade-summary"><div>${p1?smallPortrait(p1):''}<strong>${esc(p1?.name||'No player')}</strong></div><span class="trade-arrow">⇄</span><div>${p2?smallPortrait(p2):''}<strong>${esc(p2?.name||'No player')}</strong></div></div>${o.cash?`<p class="micro">Credit adjustment: ${money(o.cash)}</p>`:''}${incoming?`<div class="btn-row"><button class="btn btn-sm btn-primary" data-action="acceptOffer" data-id="${o.id}">ACCEPT OFFER</button><button class="btn btn-sm" data-action="rejectOffer" data-id="${o.id}">DECLINE</button></div>`:''}</div>`;
}
function smallPortrait(p){return `<img class="offer-portrait" src="${esc(p.imageThumb||p.image||'/assets/fallback.svg')}" data-fallback="${esc(p.imageFallback||'/api/art/'+p.id+'.svg')}" onerror="window.playerPhotoError(this)" alt="${esc(p.name)}">`;}
const TRADE_SLOTS=BASE_SLOTS;
const SHAPES=FORMATIONS;
const shapeOf=m=>SHAPES[m?.id===app.myId&&app.pendingShape||m?.formation]||SHAPES['4-3-3'];
const slotNames=m=>shapeOf(m).slots;
const ratingAt=(p,role)=>p?.positionRatings?.[role]??(role==='LM'?p?.positionRatings?.LW:role==='RM'?p?.positionRatings?.RW:null)??p?.rating??0;
function marketHint(){const r=app.room;if(!r)return '';const milestones=[6*r.managers.length,11*r.managers.length];const index=milestones.findIndex((_,i)=>!(r.transferOpened||[]).includes(i+1));if(index<0)return '';return `<div class="market-progress">NEXT TRANSFER WINDOW ${index+1} <b>${r.history?.length||0}/${milestones[index]} AUCTIONS</b></div>`;}

function slotsFor(m){
 const ids=m?.squad||[],valid=m?.lineup?.length===11&&m.lineup.every((id,i)=>!id||ids.includes(id));
 if(valid&&m.lineup.some(Boolean))return m.lineup;
 const result=Array(11).fill(null),assign=new Map();
 function works(id,slot){const p=player(id);return p.position===TRADE_SLOTS[slot]||p.secondary?.includes(TRADE_SLOTS[slot]);}
 function search(slot,seen){for(const id of ids){if(seen.has(id)||!works(id,slot))continue;seen.add(id);if(!assign.has(id)||search(assign.get(id),seen)){assign.set(id,slot);return true;}}return false;}
 for(let i=0;i<11;i++)search(i,new Set());
 for(const [id,i] of assign)result[i]=id;
 return result;
}
function tradeFeasible(ids){if(ids.length>16)return false;const assignment=Array(11).fill(null);let covered=0;
 function seek(id,seen){const p=player(id);for(let s=0;s<11;s++){if(seen.has(s)||(p.position!==TRADE_SLOTS[s]&&!p.secondary?.includes(TRADE_SLOTS[s])))continue;seen.add(s);if(!assignment[s]||seek(assignment[s],seen)){assignment[s]=id;return true;}}return false;}
 for(const id of ids)if(seek(id,new Set()))covered++;
 return 11-covered<=16-ids.length;
}
function proposalError(give=app.giveId,want=app.wantId){
 const mine=me(),other=team(app.tradeTo)||app.room?.managers.find(x=>x.id!==mine?.id);
 if(!mine||!other||!give||!want)return 'Select one player from each team.';
 if(!mine.squad.includes(give)||!other.squad.includes(want))return 'The ownership of one selected player has changed.';
 const a=mine.squad.filter(id=>id!==give).concat(want),b=other.squad.filter(id=>id!==want).concat(give);
 if(!tradeFeasible(a)||!tradeFeasible(b))return 'This swap would leave a team unable to fill its starting positions.';
 if(app.room.stage==='final'&&(a.length!==16||b.length!==16))return 'Final transfers must keep both squads at 16.';
 if(getMs(app.room.transfer?.deadline)===0)return 'The transfer window has ended.';
 return '';
}
function tradePitch(m,side){
 const lineup=slotsFor(m),onPitch=new Set(lineup.filter(Boolean)),bench=m.squad.filter(id=>!onPitch.has(id)),selected=side==='give'?app.giveId:app.wantId;
 const node=(id,slot,benchPlayer=false)=>{const p=player(id);if(!id)return `<div class="trade-empty" aria-label="Empty ${esc(slotNames(m)[slot])} position"><span>+</span><small>${esc(slotNames(m)[slot])}</small></div>`;
 const disabledTarget=side==='want'&&app.giveId&&!!proposalError(app.giveId,id);
 return `<div class="trade-player-wrap"><button type="button" data-action="${side==='give'?'selectGive':'selectWant'}" data-id="${esc(id)}" class="trade-player ${selected===id?'picked':''} ${disabledTarget?'ineligible':''}" aria-pressed="${selected===id}" title="${esc(p.name)} — ${esc(p.position)} — ${p.rating} OVR"><img src="${esc(p.image)}" data-fallback="${esc(p.imageFallback||'/api/art/'+p.id+'.svg')}" alt="" loading="lazy" onerror="window.playerPhotoError(this)"><strong>${esc(p.name)}</strong><small>${esc(benchPlayer?'BENCH':TRADE_SLOTS[slot])} · ${p.rating}</small></button><button class="inspect-player" aria-label="Inspect ${esc(p.name)}" data-action="inspect" data-id="${esc(id)}">i</button></div>`;
 };
 return `<div class="pitch trade-pitch" aria-label="${esc(m.team)} ${esc(m.formation||'4-3-3')} pitch">${shapeOf(m).rows.map(row=>`<div class="pitch-row">${row.map(i=>node(lineup[i],i)).join('')}</div>`).join('')}</div><div class="trade-bench"><div class="eyebrow">BENCH · ${bench.length} PLAYER${bench.length===1?'':'S'}</div><div class="trade-bench-row">${bench.map(id=>node(id,0,true)).join('')||'<span class="muted micro">No bench players yet</span>'}</div></div>`;
}
function squadViewer(){
 if(!app.room||!app.squadViewer)return '';
 const m=team(app.squadViewer)||me();
 return `<div class="modal-mask" id="squadMask" role="dialog" aria-modal="true" aria-label="Team formations"><div class="modal squad-dialog"><div class="space-between"><div><div class="eyebrow">LIVE SQUAD OVERVIEW</div><h3>${esc(m.team)} · ${m.squad.length}/16</h3></div><button class="btn btn-sm" data-action="closeSquad">✕ CLOSE</button></div><div class="squad-tabs">${app.room.managers.map(x=>`<button class="btn btn-sm ${m.id===x.id?'btn-primary':'btn-ghost'}" data-action="squadTeam" data-id="${x.id}">${esc(x.id===app.myId?'MY TEAM':x.team)}</button>`).join('')}</div>${tradePitchReadOnly(m)}</div></div>`;
}
function tradePitchReadOnly(m){
 const lineup=slotsFor(m),bench=m.squad.filter(id=>!lineup.includes(id));
 const slot=(id,i)=>id?`<button class="formation-profile" data-action="inspect" data-id="${esc(id)}"><img src="${esc(player(id).imageThumb||player(id).image)}" data-fallback="${esc(player(id).imageFallback||'/api/art/'+id+'.svg')}" onerror="window.playerPhotoError(this)" alt=""><strong>${esc(player(id).name)}</strong><small>${slotDisplayName(m.formation,i)} · ${player(id).rating}</small></button>`:`<div class="trade-empty"><span>+</span><small>${slotDisplayName(m.formation,i)}</small></div>`;
 return `<div class="pitch squad-pitch">${shapeOf(m).rows.map(row=>`<div class="pitch-row">${row.map(i=>slot(lineup[i],i)).join('')}</div>`).join('')}</div><div class="eyebrow" style="margin-top:15px">SUBSTITUTES · ${bench.length}</div><div class="trade-bench-row">${bench.map(id=>`<button class="formation-profile bench-profile" data-action="inspect" data-id="${id}">${smallPortrait(player(id))}<strong>${esc(player(id).name)}</strong><small>${player(id).position} · ${player(id).rating}</small></button>`).join('')}</div>`;
}
function tradeConfirmation(){
 if(!app.tradeModal)return '';
 const give=player(app.giveId),want=player(app.wantId),invalid=proposalError();
 return `<div class="modal-mask" id="tradeMask" role="dialog" aria-modal="true" aria-label="Confirm proposed trade"><div class="modal trade-dialog"><div class="eyebrow">PROPOSE AN EXCHANGE</div><h2>YOUR TRADE</h2><div class="trade-summary trade-confirm-pair"><div>${smallPortrait(give)}<strong>${esc(give.name)}</strong><small>YOU GIVE</small></div><span class="trade-arrow">⇄</span><div>${smallPortrait(want)}<strong>${esc(want.name)}</strong><small>YOU RECEIVE</small></div></div><p class="muted small">${invalid?esc(invalid):`Send a proposal to ${esc(team(app.tradeTo)?.team||'the opposing manager')}. It takes effect only if they accept.`}</p><div class="btn-row"><button class="btn btn-primary" data-action="confirmTrade" ${invalid||app.tradePending?'disabled':''}>${app.tradePending?'SENDING…':'CONFIRM PROPOSAL ↗'}</button><button class="btn" data-action="cancelTrade">CANCEL</button></div></div></div>`;
}
function pitchDisplay(m,options={}){const actual=m.lineup||[],all=m.squad||[];const rows=shapeOf(m).rows;
 return `<div class="pitch" aria-label="${esc(m.formation||'4-3-3')} lineup pitch">${rows.map(indices=>`<div class="pitch-row">${indices.map(i=>{const p=player(actual[i]);const can=options.edit==='lineup'||options.edit==='halftime';
 const allBenched=all.filter(id=>!actual.includes(id)&&!m.subbedOut?.includes(id)&&((app.byId.get(id)?.position===options.slot)||true));
 const eligible=allBenched;
 return `<div class="pitch-slot"><img src="${esc(p.image)}" data-fallback="${esc(p.imageFallback||'/api/art/'+p.id+'.svg')}" alt="" loading="lazy" onerror="window.playerPhotoError(this)"><strong title="${esc(p.name)}">${esc(p.name)}</strong><small>${slotNames(m)[i]} · ${ratingAt(p,slotNames(m)[i])}</small>${can&&eligible.length?`<select class="pitch-change" data-slot="${i}" aria-label="Replace ${esc(p.name)} at ${i}"><option value="">REPLACE</option>${eligible.map(id=>`<option value="${id}">${esc(player(id).name)}</option>`).join('')}</select>`:''}</div>`;}).join('')}</div>`).join('')}</div>`;}
function benchDisplay(m){return `<div class="bench">${m.squad.filter(id=>!m.lineup.includes(id)).map(id=>mini(player(id))).join('')}</div>`;}
function mini(p){return `<div class="mini-player"><img src="${esc(p.image)}" data-fallback="${esc(p.imageFallback||'/api/art/'+p.id+'.svg')}" alt="" loading="lazy" onerror="window.playerPhotoError(this)"><div><strong>${esc(p.name)}</strong><small>${p.position} · ${p.rating}</small></div></div>`;}
function lineup(){const m=me(),r=app.room;return `<div class="container animate-in single-fields">${headerRoom()}
<section class="panel lineup-simple-head"><div><div class="eyebrow">SQUAD PREPARATION</div><h3>PICK YOUR BEST ELEVEN.</h3><p class="muted small">Tap one of your footballers, then the position where you want them. Everyone sees your lineup.</p></div><div class="lineup-simple-actions"><span class="timer" data-clock="${r.lineupDeadline}">${remaining(r.lineupDeadline)}</span><button class="btn btn-primary" data-action="confirmLineup" ${m.ready?'disabled':''}>${m.ready?'✓ XI LOCKED':'CONFIRM MY XI ↗'}</button></div></section>
${fieldOverview('lineup')}<section class="lineup-ready-teams micro">${r.managers.map(x=>`<span class="tag">${x.ready?'✓':'○'} ${esc(x.team)}</span>`).join('')}</section></div>`;}
function matchStats(mt){const s=mt.statistics||{};
 const cell=(label,a)=>`<div class="stat-box"><strong>${(a||[0,0]).join(' – ')}</strong><small>${label}</small></div>`;
 return cell('SHOTS',s.shots)+cell('ON TARGET',s.onTarget)+cell('SAVES',s.saves)+cell('PASSING',s.completedPasses)+cell('POSSESSION %',s.possession)+cell('xG',s.xg);
}
function matchCommentary(mt){return (mt.events||[]).slice(-10).reverse().map(e=>`<li><span class="accent">${Math.floor(e.minute)}'</span> ${esc(e.text)}</li>`).join('')||'<li>Kickoff. Watch the players move.</li>';}
function match(){const r=app.room,mt=r.match,one=team(mt.teams[0]),two=team(mt.teams[1]),full=r.stage==='fulltime';
 return `<div class="container animate-in">${headerRoom()}<div class="layout-main"><div class="stack">
 <div class="scoreboard"><strong>${esc(one.team)}</strong><div class="score" id="matchScore">${mt.score[0]} : ${mt.score[1]}</div><strong>${esc(two.team)}</strong></div>
 <div class="space-between match-topbar"><span class="tag" id="matchPeriod">${full?'FULL TIME':r.stage==='halftime'?'HALFTIME':mt.half===1?'FIRST HALF':mt.half===2?'SECOND HALF':'EXTRA TIME'}</span>
 <span class="timer" data-clock="${full?mt.fullTimeDeadline:r.stage==='halftime'?mt.halftimeDeadline:mt.deadline}">${remaining(full?mt.fullTimeDeadline:r.stage==='halftime'?mt.halftimeDeadline:mt.deadline)}</span>
 <button class="btn btn-sm btn-secondary" data-action="openLiveTactics">EDIT FORMATIONS ↗</button></div>
 <div class="match-stage"><canvas id="liveMatchCanvas" aria-label="Animated, synchronized 2D match with eleven player markers from each team and a moving ball"></canvas><div id="matchLiveStatus" class="match-live-caption" aria-live="polite">${esc(mt.live?.action||'Kickoff')} · ${(mt.live?.step||0)} simulation steps</div></div>
 <div class="stats-grid match-stats" id="matchStats">${matchStats(mt)}</div>
 ${r.stage==='halftime'?halfPanel():''}
 ${full?`<section class="panel fulltime-results"><div class="eyebrow">THE FINAL WHISTLE</div><h2>FULL TIME · ${esc(team(mt.winner)?.team||'Winner')} ADVANCE</h2>${mt.penalties?`<p class="muted">Penalty shootout: ${mt.penalties.scores.join('–')}</p>`:''}<div class="goals-list">${(mt.goals||[]).map(g=>`<div>${esc(player(g.playerId).name)} · ${Math.floor(g.minute)}'${g.assistId?' · Assist '+esc(player(g.assistId).name):''}</div>`).join('')||'No goals in open play'}</div><p class="muted small">Every goal and statistic above was generated by the match-event engine.</p></section>`:''}
 <div class="panel"><div class="panel-head"><h3>MATCH EVENTS</h3><span class="tag">LIVE ACTION LOG</span></div><ul class="activity" id="matchCommentary">${matchCommentary(mt)}</ul></div>
 </div><aside class="stack"><div class="panel"><h3>THE KNOCKOUT BRACKET</h3>${bracket()}</div><div class="panel"><h3>EVERYONE IS WATCHING</h3><p class="muted small">All managers watch the same 22 players, ball positions, goals and verified match-event totals. Halftime substitutions remain restricted to five.</p>${managerRows()}</div></aside></div>
 <details class="match-live-tactics"><summary>VIEW & EDIT LIVE FORMATIONS · POSITION CHANGES ONLY</summary>${fieldOverview('match')}</details></div>`;
}
function mountMatch(){const cv=$('#liveMatchCanvas'),mt=app.room?.match;if(!cv||!mt?.live)return;
 const names=Object.fromEntries(app.catalog.map(p=>[p.id,p.name]));
 matchCanvas=new MatchCanvas(cv,names,mt.teams.map(id=>team(id)?.color||'#D9EC7B'));
 matchCanvas.update(mt.live);
}
function updateMatchOnly(){const mt=app.room?.match;if(!mt||!$('#liveMatchCanvas'))return false;
 matchCanvas?.update(mt.live);
 const score=$('#matchScore'),stats=$('#matchStats'),commentary=$('#matchCommentary'),caption=$('#matchLiveStatus');
 if(score)score.textContent=mt.score.join(' : ');
 if(stats)stats.innerHTML=matchStats(mt);
 if(commentary)commentary.innerHTML=matchCommentary(mt);
 if(caption)caption.textContent=`${(mt.live?.action||'play').toUpperCase()} · ${Math.floor(mt.simulatedMinute||mt.live?.step*.5||0)}'`;
 renderClock();return true;
}
function halfPanel(){const mt=app.room.match,m=me(),inMatch=mt.teams.includes(m?.id);if(!inMatch)return `<div class="notice">Halftime: competing managers are making tactical decisions. You are spectating.</div>`;
 return `<div class="panel"><div class="panel-head"><h3>HALFTIME // MAKE IT COUNT</h3><span class="tag">${m.subsUsed}/5 CHANGES USED</span></div><p class="muted small">Only halftime substitutions are permitted. A substituted-off footballer cannot re-enter this match.</p>${pitchDisplay(m,{edit:mt.halftimeReady.includes(m.id)?'':'halftime'})}<div class="field" style="margin-top:16px"><label for="tacticSelect">Second-half approach</label><select id="tacticSelect" ${mt.halftimeReady.includes(m.id)?'disabled':''}><option ${m.tactic==='Balanced'?'selected':''}>Balanced</option><option ${m.tactic==='Attack'?'selected':''}>Attack</option><option ${m.tactic==='Defend'?'selected':''}>Defend</option></select></div><button class="btn btn-primary" data-action="halfReady" ${mt.halftimeReady.includes(m.id)?'disabled':''}>${mt.halftimeReady.includes(m.id)?'✓ TACTICS LOCKED':'READY FOR SECOND HALF'}</button></div>`;}
function bracket(){return app.room.bracket.map(round=>`<div class="stack" style="gap:7px;margin-bottom:18px"><div class="eyebrow">ROUND ${round.round}</div>${round.pairs.map(p=>`<div class="offer-line micro" style="padding:8px;border:1px solid #ffffff20;border-radius:7px"><span>${esc(team(p.teams[0])?.team)}<br>vs ${esc(team(p.teams[1])?.team)}</span><span>${p.score?p.score.join('–'):'UP NEXT'}</span></div>`).join('')}</div>`).join('')||'<p class="muted small">Bracket preparing...</p>';}
function done(){const r=app.room,winner=team(r.champion);return `<div class="container animate-in">${headerRoom()}<section class="champion"><div class="cup">${winner?'🏆':'⚽'}</div><div class="eyebrow">${winner?'THE FINAL WHISTLE · CHAMPIONS CROWNED':'SOLO DRAFT PRACTICE COMPLETE'}</div><h1>${winner?esc(winner.team):'SQUAD COMPLETE'}</h1><p class="muted">${winner?'Built through the auction. Proven on the pitch.':'You successfully assembled and organized your dream squad.'}</p></section><div class="layout-2" style="margin-top:20px"><section class="panel"><h3>TOURNAMENT RESULTS</h3>${bracket()}</section><section class="panel"><h3>YOUR FINAL LEGENDS</h3><div class="stack">${(me()?.squad||[]).map(id=>mini(player(id))).join('')}</div></section></div><div class="btn-row" style="margin-top:22px">${me()?.id===r.hostId?'<button class="btn btn-primary" data-action="rematch">REMATCH WITH SAME MANAGERS ↗</button>':''}<button class="btn" data-action="newRoom">NEW GAME ↗</button><button class="btn btn-secondary" data-view="gallery">EXPLORE THE COLLECTION</button></div></div>`;}
function gallery(){const items=app.catalog.filter(p=>(!app.search||p.name.toLowerCase().includes(app.search.toLowerCase()))&&(!app.position||p.position===app.position));
 if(app.sort==='high')items.sort((a,b)=>b.rating-a.rating||a.name.localeCompare(b.name));
 if(app.sort==='low')items.sort((a,b)=>a.rating-b.rating||a.name.localeCompare(b.name));
 if(app.sort==='alpha')items.sort((a,b)=>a.name.localeCompare(b.name));
 const visible=items.slice(app.page*24,(app.page+1)*24);
 return `<div class="container animate-in">${title('1000','THE PRIME COMPENDIUM',`<span class="tag">${items.length} RESULTS</span>`)}<p class="muted">Explore 1,000 footballers. The photo catalog links available Wikimedia photographs to immutable player IDs. Unverified or missing photos use individually designed artwork when a source fails. Review linked sources before redistribution. Ratings are game estimates.</p><div class="gallery-toolbar"><input type="search" id="gallerySearch" placeholder="Search Messi, Zidane, Yashin..." value="${esc(app.search)}" aria-label="Search footballers"><select id="galleryPosition" aria-label="Filter footballers by position"><option value="">ALL POSITIONS</option>${['GK','RB','LB','CB','CDM','CM','CAM','RW','ST','LW'].map(pos=>`<option value="${pos}" ${app.position===pos?'selected':''}>${pos}</option>`).join('')}</select><select id="gallerySort" aria-label="Sort footballers"><option value="rank" ${app.sort==='rank'?'selected':''}>SOURCE ORDER</option><option value="high" ${app.sort==='high'?'selected':''}>TOP RATED</option><option value="low" ${app.sort==='low'?'selected':''}>LOWEST RATED</option><option value="alpha" ${app.sort==='alpha'?'selected':''}>NAME A–Z</option></select></div><div class="data-grid">${visible.map(p=>`<button class="compact-card" data-action="inspect" data-id="${p.id}"><img src="${esc(p.image)}" data-fallback="${esc(p.imageFallback||'/api/art/'+p.id+'.svg')}" loading="lazy" alt="Portrait or artwork for ${esc(p.name)}" onerror="window.playerPhotoError(this)"><strong>${esc(p.name)}</strong><small>${p.position} · ${p.rating} OVR · ${p.basePrice} CR</small></button>`).join('')}</div>${!visible.length?'<p class="muted">No players match your search.</p>':''}<div class="btn-row" style="margin-top:20px;justify-content:center"><button class="btn" data-action="galleryPrev" ${app.page===0?'disabled':''}>← PREVIOUS</button><span class="tag">PAGE ${app.page+1} / ${Math.max(1,Math.ceil(items.length/24))}</span><button class="btn" data-action="galleryNext" ${(app.page+1)*24>=items.length?'disabled':''}>NEXT →</button></div></div>`;}
function guide(){const steps=[['01 / THE LOBBY','Create a private room, invite your friends and select 1–8 humans. Add optional Easy, Normal or Expert computer managers.'],['02 / THE AUCTION','Bid on one footballer at a time. Each lot lasts 60 seconds, with a minimum increase of 10 credits and a five-second anti-sniping safeguard.'],['03 / THE CREDITS','Your budget is 1,700 + 150 × (human managers − 1). Bots receive exactly the same amount. Preserve credits to buy your full sixteen.'],['04 / THE TRANSFERS','Exactly two grand 300-second markets open after 6× and 11× the number of participating clubs completed auctions. Surprise swap only if no voluntary deal is completed in a market.'],['05 / BUILD YOUR TEAM','Buy eleven legal starters (GK, RB, CB, CB, LB, CDM, CM, CAM, RW, ST, LW) and five flexible substitutes. Full squads cannot bid.'],['06 / FINAL MARKET','Every card starts bidding at zero credits; first valid bid is 10. No other transfer markets are opened after the two milestones.'],['07 / THE TOURNAMENT','Random single-elimination seeding. Every match presents two roughly 30-second halves. Draws lead to extra time and, if necessary, penalties.'],['08 / THE HALFTIME EDGE','At halftime, change your approach to Attack, Balanced or Defend, and replace up to five footballers once. No substitutions in the second half.']];
 return `<div class="container animate-in">${title('GUIDE','PLAY LIKE A LEGEND')}<div class="rule-grid">${steps.map(s=>`<div class="rule-step"><div class="eyebrow">${s[0].split(' / ')[0]}</div><strong>${s[0].split(' / ')[1]}</strong><p>${s[1]}</p></div>`).join('')}</div><div class="notice warn" style="margin-top:26px">Player ratings and generic secondary positions are game models, not verified official football statistics. Artwork is original and deliberately not passed off as licensed photography. No cash wagering or prizes.</div><button class="btn btn-primary" data-view="arena">BACK TO ARENA ↗</button></div>`;}
function settings(){return `<div class="container animate-in">${title('OPTIONS','YOUR EXPERIENCE')}<div class="panel" style="max-width:650px"><div class="toggle"><input id="soundToggle" type="checkbox" ${app.sound?'checked':''}><label for="soundToggle" style="margin:0">Sound effects on verified interactions</label></div><div class="field"><label for="motionMode">Animation intensity</label><select id="motionMode"><option value="auto" ${app.motion==='auto'?'selected':''}>Follow device preference</option><option value="reduced" ${app.motion==='reduced'?'selected':''}>Reduced motion</option></select></div><div class="notice">Motion respects your operating system's reduced-motion setting. Game rules and network timers never depend on animations.</div><hr class="sep"><h3>CONNECTION</h3><p class="muted small">${app.connected?'Connected to the authoritative game server.':'Disconnected; attempting to reconnect automatically.'}</p>${app.room?`<p class="small">Current room: <strong>${esc(app.room.code)}</strong></p>`:''}</div>${imageManager()}</div>`;}
function imageManager(){
 if(!isHost())return `<div class="notice">To manage player pictures, create or join a room as its host. Only the host can upload pictures used by every participant.</div>`;
 const hits=app.imageSearch.trim()?app.catalog.filter(p=>p.name.toLowerCase().includes(app.imageSearch.toLowerCase())||p.id.toLowerCase()===app.imageSearch.toLowerCase()).slice(0,12):[];
 const p=app.imageId?player(app.imageId):null;
 return `<hr class="sep"><h3>PLAYER IMAGE MANAGER</h3><p class="muted small">Host-only portrait overrides. Select a player by name or ID; new images appear on cards for all connected managers. Upload images you own or have permission to use.</p><div class="field"><label for="imageSearch">Find a footballer</label><input type="search" id="imageSearch" autocomplete="off" placeholder="Search by player name or FC ID" value="${esc(app.imageSearch)}"></div><div class="image-hits">${hits.map(x=>`<button class="image-hit" data-action="imagePick" data-id="${x.id}">${smallPortrait(x)}<span>${esc(x.name)}<small>${esc(x.id)}</small></span></button>`).join('')}</div>${p?`<div class="image-picker-preview"><img id="imagePreview" src="${esc(app.imagePreview||p.image)}" data-fallback="${esc(p.imageFallback||'/api/art/'+p.id+'.svg')}" alt="Preview for ${esc(p.name)}" onerror="window.playerPhotoError(this)"><div><strong>${esc(p.name)}</strong><p class="micro">${esc(p.id)} · ${p.position} · JPG, PNG, WebP · max 2 MB</p><input id="imagePicker" type="file" accept="image/jpeg,image/png,image/webp" aria-label="Choose picture for ${esc(p.name)}"><button class="btn btn-primary btn-sm" data-action="saveImage" ${app.imageFile?'':'disabled'}>SAVE PLAYER PICTURE ↗</button></div></div>`:''}`;
}
async function uploadPortrait(){
 const chosen=app.imageFile,id=app.imageId,saved=JSON.parse(localStorage.getItem('far-session')||'null');
 if(!isHost()||!saved?.token||!id||!chosen)return showToast('Select a player and an image first.','error');
 if(chosen.size>2*1024*1024||!['image/jpeg','image/png','image/webp'].includes(chosen.type))return showToast('Use a JPG, PNG, or WebP smaller than 2 MB.','error');
 const btn=document.querySelector('[data-action="saveImage"]');if(btn){btn.disabled=true;btn.textContent='UPLOADING…';}
 try{
  const result=await fetch('/api/image/'+encodeURIComponent(id),{method:'POST',headers:{'Content-Type':chosen.type,'X-Room-Code':app.room.code,'X-Manager-Token':saved.token},body:chosen});
  if(!result.ok)throw Error((await result.text()).slice(0,170));
  const out=await result.json();const p=app.byId.get(id);if(p){p.image=out.image;p.imageThumb=out.image;p.imageOriginal=out.image;p.imageStatus='host_uploaded';p.reviewRequired=false;}
  if(app.imagePreview)URL.revokeObjectURL(app.imagePreview);
  app.imagePreview=null;app.imageFile=null;render();showToast('Player picture saved and updated for everyone.','success');
 }catch(e){showToast('Upload failed: '+e.message,'error');if(btn){btn.disabled=false;btn.textContent='SAVE PLAYER PICTURE ↗';}}
}
function modal(){if(!app.modalId)return '';const p=player(app.modalId);return `<div class="modal-mask" id="modalMask" role="dialog" aria-modal="true" aria-label="Footballer details"><div class="modal"><div class="space-between"><h3>PRIME PLAYER PROFILE</h3><button class="btn btn-sm" data-action="closeModal" aria-label="Close player details">✕</button></div><div class="modal-inner"><img src="${esc(p.image)}" data-fallback="${esc(p.imageFallback||'/api/art/'+p.id+'.svg')}" alt="Portrait or artwork for ${esc(p.name)}" onerror="window.playerPhotoError(this)"><div><div class="eyebrow">${esc(p.id)}</div><h2>${esc(p.name)}</h2><div class="btn-row"><span class="tag">${p.rating} OVR</span><span class="tag blue">${p.position}</span></div><p class="muted small">Other playable positions: ${p.secondary?.join(' / ')||'None assigned'}</p><p class="muted small">${p.perk?'Game perk: '+esc(p.perk):'No rare gameplay perk'}</p><div class="stats-grid">${Object.entries(p.attributes||{}).map(([k,v])=>`<div class="stat-box"><strong>${v}</strong><small>${k}</small></div>`).join('')}</div><hr class="sep"><p class="micro">BASE PRICE ${money(p.basePrice)} · GAME-ESTIMATED RATINGS</p><p class="muted small">Image: ${p.imageStatus==='host_uploaded'?'Host-uploaded portrait':p.imageStatus==='verified'?'Source-verified photo':p.imageStatus==='illustration_fallback'?'Original illustrated fallback':'Photo candidate — individual review required'}. ${p.imageLicense?'License: '+esc(p.imageLicense)+'. ':''}${p.imageAttribution?'Credit: '+esc(p.imageAttribution)+'. ':''}Ratings are game estimates. ${p.awardEvidence?'Award evidence: '+esc(p.awardEvidence)+'. ':''}${p.ratingReview==='source_rank_estimate_needs_research'?'Individual scouting verification is still pending.':'Editorially recalibrated; full individual scouting verification is still pending.'}${p.imageSource?` <a href="${esc(p.imageSource)}" target="_blank" rel="noopener noreferrer">PHOTO SOURCE ↗</a>`:''}</p>${isHost()?`<button class="btn btn-secondary btn-sm" data-action="pictureFor" data-id="${esc(p.id)}">CHANGE PLAYER PICTURE ↗</button>`:''}</div></div></div></div>`;}
function render(){document.body.classList.toggle('low-motion',app.motion==='reduced');document.querySelectorAll('[data-view]').forEach(node=>node.classList.toggle('active',node.dataset.view===app.view));
 let html;if(app.view==='gallery')html=gallery();else if(app.view==='guide')html=guide();else if(app.view==='settings')html=settings();else if(!app.room)html=welcome();else if(app.room.stage==='lobby')html=lobby();else if(app.room.stage==='auction')html=auction();else if(app.room.stage==='swap')html=swapView();else if(['transfer','final'].includes(app.room.stage))html=transfer();else if(app.room.stage==='lineup')html=lineup();else if(['match','halftime','fulltime'].includes(app.room.stage))html=match();else if(app.room.stage==='done')html=done();else html='<div class="container"><div class="panel">Preparing the next round…</div></div>';
 const motionOn=app.motion!=='reduced'&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const before=new Map();if(motionOn)document.querySelectorAll('[data-field-player]').forEach(node=>before.set(node.dataset.fieldPlayer,node.getBoundingClientRect()));
 const hadFields=!!document.querySelector('.field-grid');
 if(matchCanvas){matchCanvas.stop();matchCanvas=null;}
 $('#screen').innerHTML=html+squadViewer()+modal()+tradeConfirmation();
 if(app.view==='arena'&&app.room&&['match','halftime','fulltime'].includes(app.room.stage))mountMatch();
 if(hadFields&&motionOn&&document.querySelector('.field-grid'))document.querySelectorAll('[data-field-player]').forEach(node=>{const rect=before.get(node.dataset.fieldPlayer);if(!rect)return;const next=node.getBoundingClientRect(),x=rect.left-next.left,y=rect.top-next.top;if(Math.abs(x)>3||Math.abs(y)>3)node.animate([{transform:`translate(${x}px, ${y}px) scale(1.05)`,filter:'brightness(1.4)'},{transform:'translate(0,0) scale(1)',filter:'brightness(1)'}],{duration:360,easing:'cubic-bezier(.2,.75,.25,1)'});});
 showActionAlerts();renderClock();}
function renderClock(){document.querySelectorAll('[data-clock]').forEach(e=>{const date=Number(e.dataset.clock);e.textContent=remaining(date);e.classList.toggle('urgent',getMs(date)<(app.room?.stage==='transfer'?30000:10000));});
 const r=app.room;if(r?.stage==='auction'&&r.auction&&getMs(r.auction.deadline)>0&&getMs(r.auction.deadline)<=10000&&app.auctionWarned!==r.auction.id){app.auctionWarned=r.auction.id;showToast('AUCTION ENDING — 10 seconds remaining.','warning',4500);}
} 
function copy(s){navigator.clipboard?.writeText(s).then(()=>showToast('Copied to clipboard.')).catch(()=>showToast('Copy is unavailable in this browser.'));}
function doAction(el){const a=el.dataset.action,id=el.dataset.id,m=me();
 if(a==='openLiveTactics'){const details=document.querySelector('.match-live-tactics');if(details){details.open=true;details.scrollIntoView({block:'start',behavior:'smooth'});}return;}
 if(a==='fieldMyClub'){app.clubFocus=app.myId;app.moveSource=null;render();document.querySelector(`[data-field-team="${CSS.escape(app.myId)}"]`)?.scrollIntoView({block:'nearest',behavior:'smooth'});return;}
 if(a==='fieldTeam'){app.clubFocus=el.dataset.team;app.moveSource=null;render();return;}
 if(a==='toggleFieldEdit'){app.editMode=!app.editMode;app.moveSource=null;render();return;}
 if(a==='clearFieldTrade'){app.giveId='';app.wantId='';app.tradeModal=false;render();return;}
 if(a==='fieldSlot'){
  const owner=el.dataset.team,index=Number(el.dataset.slot),id=el.dataset.id,mine=owner===app.myId;
  const phase=app.room?.stage,editing=mine&&app.editMode;
  app.clubFocus=owner;
  if(editing){
   const self=me(),lineup=(app.pendingLineup||slotsFor(self)),bench=self.squad.filter(x=>!lineup.includes(x));
   const active=index<11?lineup[index]:bench[index-11];
   if(app.moveSource==null){if(!active){showToast('Choose a player first.');return;}app.moveSource=index;render();return;}
   if(app.moveSource===index){app.moveSource=null;render();return;}
   moveFormation(index);return;
  }
  if(phase==='transfer'){
   if(!id){showToast('This position is still empty.');return;}
   if(mine){app.giveId=app.giveId===id?'':id;app.wantId='';app.tradeModal=false;render();return;}
   if(!app.giveId){showToast('First choose a player on YOUR pitch.');return;}
   const previousTo=app.tradeTo;app.tradeTo=owner;const reason=proposalError(app.giveId,id);if(reason){app.tradeTo=previousTo;showToast(reason,'warning');return;}
   app.wantId=app.wantId===id?'':id;app.tradeModal=!!app.wantId;render();return;
  }
  if(id){app.modalId=id;render();}return;
 }

 if(a==='clubView'){app.clubFocus=id;app.moveSource=null;render();return;}
 if(a==='clubClose'){app.clubFocus=null;app.moveSource=null;render();return;}
 if(a==='formationSlot'){const index=Number(el.dataset.slot);if(app.moveSource==null){const manager=me(),lineup=slotsFor(manager),bench=manager.squad.filter(x=>!lineup.includes(x));const active=index<11?lineup[index]:bench[index-11];if(!active)return showToast('Choose a player to move first.');app.moveSource=index;render();return;}moveFormation(index);return;}
 if(a==='undoFormation'){if(!app.lastFormation)return showToast('No change to undo yet.');send('formation',{lineup:app.lastFormation,shape:app.lastShape||m.formation});app.lastFormation=null;app.moveSource=null;return;}
 if(a==='dismissToast'){$('#toast').hidden=true;return;}
 if(a==='closeArenaPop'){$('#arenaEvent').hidden=true;return;}
 if(a==='viewSquad'){app.squadViewer=m?.id||app.room?.managers[0]?.id;render();return;}
 if(a==='closeSquad'){app.squadViewer=null;render();return;}
 if(a==='squadTeam'){app.squadViewer=id;render();return;}
 if(a==='selectGive'||a==='selectWant'){
  const name=a==='selectGive'?'giveId':'wantId';const other=name==='giveId'?'wantId':'giveId';
  if(app[name]===id){app[name]='';}else{
   if(name==='wantId'&&app.giveId){const reason=proposalError(app.giveId,id);if(reason){showToast(reason,'warning');return;}}
   if(name==='giveId'&&app.wantId){const reason=proposalError(id,app.wantId);if(reason){app.wantId='';showToast('Choose a compatible opponent after selecting this player.','warning');}}
   app[name]=id;
  }
  if(app.giveId&&app.wantId){app.tradeModal=true;}render();return;
 }
 if(a==='reviewTrade'){if(!app.giveId||!app.wantId)return showToast('Select two players first.');app.tradeModal=true;render();return;}
 if(a==='cancelTrade'){app.tradeModal=false;render();return;}
 if(a==='confirmTrade'){const reason=proposalError();if(reason)return showToast(reason,'error');if(app.tradePending)return;
  app.tradePending=true;send('offer',{to:app.tradeTo,giveId:app.giveId,wantId:app.wantId,cash:0});render();return;
 }
 if(a==='goOffers'){app.view='arena';app.squadViewer=null;render();document.getElementById('offersArea')?.scrollIntoView({behavior:'smooth',block:'start'});return;}
 if(a==='imagePick'){app.imageId=id;app.imageFile=null;if(app.imagePreview)URL.revokeObjectURL(app.imagePreview);app.imagePreview=null;render();return;}
 if(a==='saveImage'){uploadPortrait();return;}
 if(a==='pictureFor'){app.imageId=id;app.imageSearch=player(id).name;app.modalId=null;app.squadViewer=null;app.view='settings';render();return;}

 if(a==='start')send('start');if(a==='toggleReady')send('ready',{ready:!m.ready});
 if(a==='saveName')send('rename',{name:$('#nameEdit').value,team:$('#teamEdit').value});
 if(a==='hostConfig')send('configure',{humans:+$('#hostHumans').value,bots:+$('#hostBots').value,difficulty:$('#hostDifficulty').value});
 if(a==='leave'){if(confirm('Leave this lobby?')){send('leave');app.room=null;app.myId=null;localStorage.removeItem('far-session');render();}}
 if(a==='pass')send('pass');if(a==='endAuction')send('endAuction');if(a==='showSquad'){app.modalId=m.squad.at(-1)||null;if(app.modalId)render();else showToast('You have not acquired a footballer yet.');}
 if(a==='endTransfers')send('endTransfers');if(a==='acceptOffer')send('reply',{id,accept:true});if(a==='rejectOffer')send('reply',{id,accept:false});
 if(a==='confirmLineup')send('confirmLineup');if(a==='halfReady')send('halfReady');
 if(a==='copyCode')copy(app.room.code);if(a==='copyLink')copy(`${location.origin}/?room=${app.room.code}`);
 if(a==='inspect'){app.modalId=id;render();}if(a==='closeModal'){app.modalId=null;render();}
 if(a==='galleryPrev'){app.page=Math.max(0,app.page-1);render();scrollTo({top:0,behavior:'smooth'});}if(a==='galleryNext'){app.page++;render();scrollTo({top:0,behavior:'smooth'});}
 if(a==='rematch'){if(confirm('Start a fresh rematch with the current participants?'))send('rematch');}
 if(a==='newRoom'){app.squadViewer=null;app.tradeModal=false;localStorage.removeItem('far-session');app.room=null;app.myId=null;app.socket?.close();app.view='arena';render();}
}
function activateGameControl(e){const target=e.target.closest('[data-view],[data-action]');if(target){if(target.dataset.view){app.view=target.dataset.view;app.modalId=null;render();}else doAction(target);return;}if(e.target?.id==='modalMask'){app.modalId=null;render();}if(e.target?.id==='tradeMask'){app.tradeModal=false;render();}if(e.target?.id==='squadMask'){app.squadViewer=null;render();}}
document.addEventListener('click',activateGameControl);
document.addEventListener('mousedown',e=>{if(e.button===1&&e.target.closest('[data-action],[data-view],button[type=submit]'))e.preventDefault();});
document.addEventListener('auxclick',e=>{if(e.button!==1)return;const item=e.target.closest('button[data-action],button[data-view],button[type=submit]');if(!item||item.disabled)return;e.preventDefault();if(item.matches('button[type=submit]')&&!item.hasAttribute('data-action')){item.closest('form')?.requestSubmit(item);return;}activateGameControl(e);});
document.addEventListener('change',e=>{if(!e.target.matches('[data-formation-select]'))return;
 const m=me();if(!m)return;const nextShape=e.target.value;if(!SHAPES[nextShape])return;
 app.lastFormation=slotsFor(m).slice();app.lastShape=m.formation;app.pendingShape=nextShape;
 send('formation',{lineup:app.pendingLineup||slotsFor(m),shape:nextShape});render();
});
document.addEventListener('dragstart',e=>{const x=e.target.closest('.club-slot[draggable=true],.field-slot[draggable=true]');if(!x)return;app.moveSource=Number(x.dataset.slot);e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',String(app.moveSource));});
document.addEventListener('dragover',e=>{if(e.target.closest('.club-slot[data-action=formationSlot],.field-slot[data-action=fieldSlot]'))e.preventDefault();});
document.addEventListener('drop',e=>{const x=e.target.closest('.club-slot[data-action=formationSlot],.field-slot[data-action=fieldSlot]');if(!x)return;e.preventDefault();const src=Number(e.dataTransfer.getData('text/plain'));if(!Number.isInteger(src))return;app.moveSource=src;moveFormation(Number(x.dataset.slot));});
document.addEventListener('dragend',()=>{app.moveSource=null;});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){app.modalId=null;app.squadViewer=null;app.tradeModal=false;render();}});
document.addEventListener('submit',e=>{if(!['createForm','joinForm','bidForm','offerForm'].includes(e.target.id))return;e.preventDefault();const f=e.target;
 if(f.id==='createForm'){const d=Object.fromEntries(new FormData(f));d.humans=+d.humans;d.bots=+d.bots;if(d.humans+d.bots>8){showToast('Total managers cannot exceed eight.');return;}send('create',d);}
 if(f.id==='joinForm'){const d=Object.fromEntries(new FormData(f));send('join',d);}
 if(f.id==='bidForm'){send('bid',{amount:+$('#bidInput').value});}
 if(f.id==='offerForm'){send('offer',{to:$('#tradeTo').value,giveId:$('#giveId').value,wantId:$('#wantId').value,cash:+$('#cash').value});}
});
document.addEventListener('input',e=>{if(e.target.id==='bidInput')app.bidDraft=e.target.value;
 if(e.target.id==='cash')app.cash=e.target.value;
 if(e.target.id==='imageSearch'){app.imageSearch=e.target.value;const caret=e.target.selectionStart;render();const inp=$('#imageSearch');inp?.focus();inp?.setSelectionRange(caret,caret);}
 if(e.target.id==='gallerySearch'){app.search=e.target.value;app.page=0;const caret=e.target.selectionStart;render();const input=$('#gallerySearch');input.focus();input.setSelectionRange(caret,caret);}
 if(e.target.id==='humans'||e.target.id==='bots'){const humans=+$('#humans').value,bots=$('#bots');const allowed=8-humans;if(+bots.value>allowed)bots.value=allowed;[...bots.options].forEach(o=>o.disabled=+o.value>allowed);$('#budgetPreview').textContent=`${humans} human · ${bots.value} AI · ${money(1700+150*(humans-1))} credits per team`;}
});
document.addEventListener('change',e=>{
 if(e.target.id==='galleryPosition'){app.position=e.target.value;app.page=0;render();}
 if(e.target.id==='gallerySort'){app.sort=e.target.value;app.page=0;render();}
 if(e.target.id==='hostHumans'){const h=+e.target.value,b=$('#hostBots');b.innerHTML=Array.from({length:9-h},(_,i)=>`<option value="${i}" ${i===Math.min(+b.value,8-h)?'selected':''}>${i}</option>`).join('');}
 if(e.target.id==='tradeOpponent'||e.target.id==='tradeTo'){app.tradeTo=e.target.value;app.wantId='';app.tradeModal=false;render();}
 if(e.target.id==='giveId')app.giveId=e.target.value;
 if(e.target.id==='wantId')app.wantId=e.target.value;
 if(e.target.id==='imagePicker'){const file=e.target.files?.[0];if(app.imagePreview)URL.revokeObjectURL(app.imagePreview);app.imagePreview=null;app.imageFile=null;if(file){if(file.size>2*1024*1024||!['image/jpeg','image/png','image/webp'].includes(file.type))return showToast('Use a valid JPG, PNG, or WebP file under 2 MB.','error');app.imageFile=file;app.imagePreview=URL.createObjectURL(file);}const img=$('#imagePreview');if(img&&app.imagePreview)img.src=app.imagePreview;const btn=$('[data-action=saveImage]');if(btn)btn.disabled=!app.imageFile;}
 if(e.target.id==='soundToggle'){app.sound=e.target.checked;localStorage.setItem('far-sound',app.sound?'on':'off');ding();}
 if(e.target.id==='motionMode'){app.motion=e.target.value;localStorage.setItem('far-motion',app.motion);render();}
 if(e.target.id==='tacticSelect')send('tactic',{value:e.target.value});
 if(e.target.classList.contains('pitch-change')&&e.target.value){const slot=Number(e.target.dataset.slot),id=e.target.value,m=me();if(app.room.stage==='lineup'){const lineup=m.lineup.slice();lineup[slot]=id;send('lineup',{lineup});}else if(app.room.stage==='halftime'){send('sub',{slot,inId:id});}}
});
let stored=JSON.parse(localStorage.getItem('far-session')||'null');const roomParam=new URLSearchParams(location.search).get('room');
if(roomParam&&(!stored||stored.code!==roomParam.toUpperCase())){localStorage.removeItem('far-session');app.view='arena';}
loadCatalog();connect();setInterval(renderClock,450);
