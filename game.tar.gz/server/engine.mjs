import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { randomBytes } from 'node:crypto';
import {BASE_SLOTS,FORMATIONS,formationSlots} from '../public/formations.mjs';
import {newSimulation,stepSimulation,resolvePenalties,validateSimulation,computeStats} from './simulation.mjs';
const here=dirname(fileURLToPath(import.meta.url));
export const CARDS=JSON.parse(readFileSync(resolve(here,'../data/players.json'),'utf8'));
export const BY_ID=new Map(CARDS.map(c=>[c.id,c]));
export const SLOTS=BASE_SLOTS;
export {FORMATIONS};
export const BUDGET=h=>1700+150*(h-1);
export const teamSlots=m=>formationSlots(m?.formation);
export const MARKET_MULTIPLIERS=[6,11];
export const TRANSFER_SECONDS=300;
export const marketMilestones=room=>MARKET_MULTIPLIERS.map(x=>x*room.managers.length);
// Assigned-position ratings are GAME ESTIMATES, not verified historic ratings.
// Base OVR never changes; only the effective match contribution does.
const GROUPS={GK:'GK',RB:'DEF',LB:'DEF',CB:'DEF',RWB:'DEF',LWB:'DEF',CDM:'MID',CM:'MID',CAM:'MID',RM:'MID',LM:'MID',RW:'ATT',LW:'ATT',ST:'ATT',CF:'ATT'};
const ADJACENT={RB:['CB','LB','RW','CM'],LB:['CB','RB','LW','CM'],CB:['RB','LB','CDM'],CDM:['CM','CB','CAM'],CM:['CDM','CAM','RW','LW'],CAM:['CM','RW','LW','ST','CDM'],RW:['LW','ST','CAM','RM','RB'],LW:['RW','ST','CAM','LM','LB'],RM:['RW','CM','RB'],LM:['LW','CM','LB'],CF:['ST','LW','RW','CAM'],ST:['RW','LW','CAM','CF']};
export function positionRating(p,slot){
 if(!p||!Object.hasOwn(GROUPS,slot))return 20;
 if(slot===p.position)return p.rating;
 const attrs=p.attributes||{},group=GROUPS[slot],natural=GROUPS[p.position];
 const stat=group==='GK'?(attrs.GK||35):group==='DEF'?(attrs.DEF||50):group==='MID'?(attrs.MID||50):(attrs.ATT||50);
 const naturalStat=natural==='GK'?(attrs.GK||35):natural==='DEF'?(attrs.DEF||50):natural==='MID'?(attrs.MID||50):(attrs.ATT||50);
 if(slot==='GK' || p.position==='GK')return Math.max(20,Math.min(45,Math.round(p.rating-54+(stat-naturalStat)*.13)));
 const adjacent=ADJACENT[p.position]?.includes(slot);
 const secondary=(p.secondary||[]).includes(slot);
 let penalty=secondary?3:adjacent?10:group===natural?13:25;
 penalty+=Math.max(-5,Math.min(12,Math.round((naturalStat-stat)*.18)));
 return Math.max(20,Math.min(p.rating,Math.round(p.rating-penalty)));
}

export const SWAP_CHECKPOINTS=[3,6,9,12,15];
function event(room,type,details={}){room.events??=[];room.events.push({id:uid(),at:now(),type,...details});room.events=room.events.slice(-35);}
function draftWins(room,m){return Number.isInteger(m.draftWins)?m.draftWins:room.ledger.filter(e=>e.type==='auction'&&e.managerId===m.id).length;}
export function nextSwapCheckpoint(room){return SWAP_CHECKPOINTS.find(n=>!(room.swapCompleted||[]).includes(n)&&room.managers.every(m=>draftWins(room,m)>=n))||null;}

export const uid=()=>randomBytes(14).toString('hex');
export const rnd=n=>Math.floor(Math.random()*n);
const range=(a,b)=>a+Math.random()*(b-a);
export const now=()=>Date.now();
export const managerOf=(room,id)=>room.managers.find(m=>m.id===id);
export function fit(p,slot){
 if(!p)return -1;
 if(p.position===slot)return 1;
 if(p.position==='CB'&&slot==='CB')return 1;
 // Generalized flexibility is displayed as game rules, NOT asserted as historical fact.
 if((p.secondary||[]).includes(slot))return .87;
 return -1;
}
export function bestLineup(ids){
 const players=ids.map(id=>BY_ID.get(id)).filter(Boolean);
 let dp=Array(2048).fill(null); dp[0]={score:0,lineup:Array(11).fill(null)};
 for(const p of players){
  const next=dp.slice();
  for(let mask=0;mask<2048;mask++){
   const v=dp[mask];if(!v)continue;
   for(let j=0;j<11;j++){
    if(mask&(1<<j))continue;
    const suitability=fit(p,SLOTS[j]); if(suitability<0)continue;
    const score=v.score + p.rating*suitability;
    const k=mask|(1<<j);
    if(!next[k]||next[k].score<score){const lineup=v.lineup.slice();lineup[j]=p.id;next[k]={score,lineup};}
   }
  }
  dp=next;
 }
 let best=dp[0], maskBest=0, countBest=0;
 for(let mask=0;mask<2048;mask++){const d=dp[mask];if(!d)continue;
  const n=mask.toString(2).replaceAll('0','').length;
  if(n>countBest||(n===countBest&&d.score>best.score)){best=d;countBest=n;maskBest=mask;}
 }
 return {lineup:best.lineup,covered:countBest,score:best.score,complete:!!dp[2047]};
}
function coverage(ids){
 const players=ids.map(id=>BY_ID.get(id)).filter(Boolean);
 const assigned=Array(players.length).fill(-1);
 function augment(slot,seen){for(let j=0;j<players.length;j++){
  if(seen.has(j)||fit(players[j],SLOTS[slot])<0)continue;
  seen.add(j);
  if(assigned[j]===-1||augment(assigned[j],seen)){assigned[j]=slot;return true;}
 }return false;}
 let covered=0;for(let slot=0;slot<11;slot++)if(augment(slot,new Set()))covered++;
 return covered;
}
export function feasible(ids){return ids.length<=16 && (11-coverage(ids))<=16-ids.length;}

export function validPlacement(squad,eleven,complete=false){
 if(!Array.isArray(eleven)||eleven.length!==11)return false;
 const ids=eleven.filter(Boolean);
 return (!complete||ids.length===11)&&ids.length===new Set(ids).size&&ids.every(id=>squad.includes(id)&&BY_ID.has(id));
}
export function validateLineup(squad,eleven){return validPlacement(squad,eleven,true);}
export function setFormation(room,actor,lineup,shape){
 if(room.stage==='done')throw Error('Game has ended');
 if(!FORMATIONS[shape||actor.formation||'4-3-3'])throw Error('Unknown tactical formation');
 if(!validPlacement(actor.squad,lineup))throw Error('Select only footballers you own, with no duplicates');
 const nextShape=shape||actor.formation||'4-3-3';
 // Once a match has begun, tactical edits must retain the SAME eleven on the pitch.
 // Halftime substitutions use the separately validated 'sub' action instead.
 if(['match','halftime','tournament','fulltime'].includes(room.stage)){
  const before=(actor.lineup||[]).filter(Boolean).sort().join('|');
  const after=lineup.filter(Boolean).sort().join('|');
  if(before!==after)throw Error('Only positional changes are allowed now; substitutions are halftime only');
 }
 if(room.stage==='match' && room.match?.teams.includes(actor.id)){
  actor.pendingTactics={lineup:lineup.slice(),formation:nextShape};
  return;
 }
 actor.lineup=lineup.slice();actor.formation=nextShape;
 actor.pendingTactics=null;
 event(room,'formationChanged',{teamId:actor.id,formation:nextShape});
}
function applyPendingTactics(room){
 for(const manager of room.managers){const pending=manager.pendingTactics;if(!pending)continue;
  if(validPlacement(manager.squad,pending.lineup) &&
    manager.lineup.filter(Boolean).sort().join('|')===pending.lineup.filter(Boolean).sort().join('|')){
   manager.lineup=pending.lineup;manager.formation=pending.formation;
   event(room,'formationChanged',{teamId:manager.id,formation:manager.formation});
  }
  manager.pendingTactics=null;
 }
}
function refreshPlacement(m){
 if(m.lineup?.length!==11)return;
 const retained=m.lineup.map(id=>m.squad.includes(id)?id:null);
 const available=m.squad.filter(id=>!retained.includes(id));
 for(const id of available){const p=BY_ID.get(id);
  const preferred=retained.findIndex((x,i)=>!x&&fit(p,SLOTS[i])>0);
  if(preferred>=0)retained[preferred]=id;
 }
 m.lineup=retained;
}

export const publicManager=m=>{const {token,...rest}=m;return rest;};
export function publicRoom(room){const {log,...rest}=room;const match=room.match?((({sim,...visible})=>visible)(room.match)):null;return {...rest,match,managers:room.managers.map(publicManager),log:room.log.slice(-38)};}
export function createRoom(opts,hostName){
 const humans=Math.min(8,Math.max(1,Math.trunc(Number(opts.humans)||1)));
 const bots=Math.min(8-humans,Math.max(0,Math.trunc(Number(opts.bots)||0)));
 const difficulty=['Easy','Normal','Expert'].includes(opts.difficulty)?opts.difficulty:'Normal';
 const host={id:uid(),token:uid(),name:sanitize(hostName),team:sanitize(opts.team||`${hostName||'Host'} FC`),color:'#D8F36A',human:true,online:true,aiControl:false,ready:true,credits:0,squad:[],lineup:[],subbedOut:[],subsUsed:0,tactic:'Balanced',formation:'4-3-3',pendingTactics:null,eliminated:false,draftWins:0};
 const room={id:uid(),code:randomBytes(4).toString('hex').slice(0,6).toUpperCase(),title:sanitize(opts.title||'LEGENDS AUCTION NIGHT'),hostId:host.id,
 settings:{humans,bots,difficulty,budgetMode:'auto'},stage:'lobby',managers:[host],auctionNo:0,auction:null,transfer:null,
 unsold:{},history:[],log:[],ledger:[],offers:[],bracket:[],remainingTeams:[],nextRound:[],roundPairs:[],pairIndex:0,match:null,createdAt:now(),updatedAt:now(),champion:null,swap:null,swapCompleted:[],transferOpened:[],events:[]};
 return {room,host};
}
export function sanitize(s){return String(s||'Manager').replace(/[\u0000-\u001f<>]/g,'').trim().slice(0,40)||'Manager';}
export function join(room,name){if(room.stage!=='lobby')throw Error('Game has already started');if(room.managers.filter(m=>m.human).length>=room.settings.humans)throw Error('Human slots are full');
 const m={id:uid(),token:uid(),name:sanitize(name),team:sanitize(`${name||'Manager'} FC`),color:['#5FE0CB','#D7A7FF','#F7A964','#77BDFF','#FF8CAA'][room.managers.length%5],human:true,online:true,aiControl:false,ready:false,credits:0,squad:[],lineup:[],subbedOut:[],subsUsed:0,tactic:'Balanced',formation:'4-3-3',pendingTactics:null,eliminated:false,draftWins:0};
 room.managers.push(m);return m;}
export function start(room,actor){
 if(room.stage!=='lobby'||room.hostId!==actor.id)throw Error('Only the host can start the lobby');
 if(room.managers.filter(m=>m.human).length!==room.settings.humans)throw Error('Waiting for all human slots');
 if(room.managers.some(m=>!m.ready))throw Error('Not everyone is ready');
 for(let i=0;i<room.settings.bots;i++)room.managers.push({id:uid(),token:null,name:`AI ${i+1}`,team:['ATLAS UNITED','NOVA ATHLETIC','IVORY CITY','VORTEX FC','ECLIPSE XI','TITAN SC','APEX ROVERS'][i],color:['#E19CFC','#EFBA7B','#88ADFF','#8EE8CB'][i%4],human:false,online:true,aiControl:true,ready:true,credits:0,squad:[],lineup:[],subbedOut:[],subsUsed:0,tactic:'Balanced',formation:'4-3-3',pendingTactics:null,eliminated:false,draftWins:0});
 // Fresh games have NO OWNERSHIP. No cards are allocated during room creation or start.
 room.ledger=[];room.history=[];room.unsold={};room.swapCompleted=[];room.transferOpened=[];room.auctionNo=0;
 for(const m of room.managers){m.credits=BUDGET(room.settings.humans);m.squad=[];m.lineup=[];m.draftWins=0;m.subbedOut=[];m.subsUsed=0;m.pendingTactics=null;m.formation=m.formation||'4-3-3';}

 room.stage='auction';room.log.push({at:now(),text:`The arena is open • ${room.managers.length} managers • ${BUDGET(room.settings.humans)} credits each`});
 beginAuction(room);return room;
}
const POS=['GK','RB','CB','LB','CDM','CM','CAM','RW','ST','LW'];
// Position need is chosen BEFORE fame weighting so iconic forwards cannot
// consume the supply needed by goalkeepers, defenders and midfielders.
// Probability varies with completed auctions; revealed unsold cards remain
// unavailable until eight OTHER auctions have taken place.
export function chooseCard(room,rng=Math.random){
 const owned=new Set(room.managers.flatMap(m=>m.squad));
 const missing={};for(const pos of POS)missing[pos]=0;
 for(const m of room.managers){if(m.squad.length===16)continue;const found=bestLineup(m.squad).lineup;
  for(let i=0;i<11;i++)if(!found[i])missing[SLOTS[i]]+=1;
 }
 const need=POS.map(pos=>({pos,weight:1+(missing[pos]||0)*3+(pos==='CB'?1:0)}));
 let draw=rng()*need.reduce((s,x)=>s+x.weight,0),chosen=need.at(-1).pos;
 for(const candidate of need){draw-=candidate.weight;if(draw<=0){chosen=candidate.pos;break;}}
 const eligibleAll=CARDS.filter(p=>!owned.has(p.id)&&(!room.unsold[p.id]||room.auctionNo-room.unsold[p.id]>=9));
 const pool=eligibleAll.filter(p=>p.position===chosen);
 const eligible=pool.length?pool:eligibleAll;
 if(!eligible.length)throw Error('No eligible footballers remain in the auction database');
 const progress=room.auctionNo/Math.max(1,room.managers.length*16);
 const earlyBias=progress<=.25?.60:progress<=.65?.29:.12;
 const recognizable=eligible.filter(p=>p.recognitionPriority>=70);
 const options=recognizable.length&&rng()<earlyBias?recognizable:eligible;
 // Within the weighted draw, different values provide variation without
 // imposing a sorted, deterministic order or changing any playing ratings.
 const weights=options.map(p=>options===recognizable?Math.max(1,p.recognitionPriority||30):1);
 let remaining=rng()*weights.reduce((x,y)=>x+y,0);
 for(let i=0;i<options.length;i++){remaining-=weights[i];if(remaining<=0)return options[i];}
 return options.at(-1);
}

export function beginAuction(room){
 if(room.managers.every(m=>m.squad.length===16)){beginLineup(room);return;}
 room.auctionNo++;
 const card=chooseCard(room);
 room.stage='auction';room.offers=[];
 room.auction={id:uid(),cardId:card.id,number:room.auctionNo,openedAt:now(),deadline:now()+60000,highestBid:0,leader:null,votes:[],passed:[],botAt:now()+range(1600,4000)};
 room.log.push({at:now(),text:`LOT ${room.auctionNo} — ${card.name} (${card.position}) is on the block`});
}
export function maxBid(room,m){return Math.max(0,m.credits-(16-m.squad.length-1)*20);}
export function placeBid(room,actor,amount){const a=room.auction;if(room.stage!=='auction'||!a||now()>a.deadline)throw Error('Bidding is closed');
 if(actor.squad.length>=16)throw Error('Your 16-player squad is full');
 if(a.passed.includes(actor.id))throw Error('You have passed this lot');
 const card=BY_ID.get(a.cardId),min=a.highestBid?a.highestBid+10:10;
 if(!Number.isSafeInteger(amount)||amount<min||amount%10!==0||amount>maxBid(room,actor))throw Error(`Bid must be at least ${min}, follow 10-credit steps and leave enough for empty slots`);
 if(!feasible([...actor.squad,card.id]))throw Error('That purchase would prevent filling your starting eleven');
 a.highestBid=amount;a.leader=actor.id;a.votes=[];
 if(a.deadline-now()<5000)a.deadline=now()+5000;
 room.log.push({at:now(),text:`${actor.name} bid ${amount} for ${card.name}`});
}
export function voteAuction(room,actor){if(room.stage!=='auction')throw Error('There is no live auction');
 if(!room.auction.votes.includes(actor.id))room.auction.votes.push(actor.id);
 if(room.auction.votes.length===room.managers.length)closeAuction(room);
}
export function passAuction(room,actor){if(room.stage!=='auction')throw Error('There is no live auction');
 if(room.auction.leader===actor.id)throw Error('Current leading bidder cannot pass');
 if(!room.auction.passed.includes(actor.id))room.auction.passed.push(actor.id);
}
export function closeAuction(room){const a=room.auction;if(room.stage!=='auction'||!a)return;
 if(a.leader){const winner=managerOf(room,a.leader);const card=BY_ID.get(a.cardId);
  if(!winner||winner.squad.length>=16||winner.credits<a.highestBid||!feasible([...winner.squad,card.id]))throw Error('Invalid winning bid state');
  const before=winner.credits;winner.credits-=a.highestBid;winner.squad.push(card.id);winner.draftWins=draftWins(room,winner)+1;refreshPlacement(winner);
  room.ledger.push({at:now(),type:'auction',managerId:winner.id,cardId:card.id,before,delta:-a.highestBid,after:winner.credits});
  room.log.push({at:now(),text:`SOLD — ${card.name} → ${winner.team} for ${a.highestBid} credits`});
  event(room,'signed',{cardId:card.id,teamId:winner.id,credits:a.highestBid,auctionId:a.id});
 }else {room.unsold[a.cardId]=a.number;room.log.push({at:now(),text:`UNSOLD — ${BY_ID.get(a.cardId).name} can return after eight other auctions`});}
 room.history.push({...a,closedAt:now(),soldTo:a.leader});
 advanceAfterAuction(room);
}
function advanceAfterAuction(room){
 if(room.managers.every(m=>m.squad.length===16)){beginLineup(room);return;}
 const completed=room.history.length,milestones=marketMilestones(room);
 const at=milestones.findIndex((count,i)=>count===completed&&!(room.transferOpened||[]).includes(i+1));
 if(at>=0){beginTransfer(room,at+1);return;}
 beginAuction(room);
}
export function beginTransfer(room,ordinal){
 if(![1,2].includes(ordinal)||(room.transferOpened||[]).includes(ordinal))throw Error('Transfer window already opened');
 room.transferOpened??=[];room.transferOpened.push(ordinal);
 room.stage='transfer';room.offers=[];
 room.transfer={id:uid(),ordinal,final:false,deadline:now()+TRANSFER_SECONDS*1000,votes:[],voluntary:0,closed:false,botAt:now()+4000,proposedBy:[]};
 event(room,'marketOpen',{ordinal});
 room.log.push({at:now(),text:`TRANSFER WINDOW ${ordinal} • ${TRANSFER_SECONDS} seconds • milestone ${room.history.length}/${marketMilestones(room)[ordinal-1]}`});
}
export function transferAllowed(room,from,to,giveId,wantId,cash){
 if(from.id===to.id)throw Error('Select another manager');
 if(!Number.isSafeInteger(cash)||Math.abs(cash)>10000)throw Error('Invalid credit transfer');
 if(!giveId&&!wantId)throw Error('Select at least one footballer');
 if(giveId&&!from.squad.includes(giveId))throw Error('Proposer does not own outgoing footballer');
 if(wantId&&!to.squad.includes(wantId))throw Error('Recipient does not own requested footballer');
 if((cash>0&&from.credits<cash)||(cash<0&&to.credits<(-cash)))throw Error('Insufficient credits for transfer');
 const a=from.squad.filter(id=>id!==giveId).concat(wantId?[wantId]:[]);
 const b=to.squad.filter(id=>id!==wantId).concat(giveId?[giveId]:[]);
 if(a.length>16||b.length>16||!feasible(a)||!feasible(b))throw Error('Trade would violate squad capacity or starting-position coverage');
 if(room.stage==='final'&&(a.length!==16||b.length!==16))throw Error('Final-market deals must preserve both complete 16-player squads');
 return {a,b};
}
export function offerTrade(room,actor,details){
 if(!['transfer','final'].includes(room.stage)||now()>room.transfer.deadline)throw Error('Transfer market is closed');
 const other=managerOf(room,details.to);if(!other)throw Error('Recipient not found');
 const giveId=details.giveId||null,wantId=details.wantId||null,cash=Number(details.cash||0);
 transferAllowed(room,actor,other,giveId,wantId,cash);
 const offer={id:uid(),from:actor.id,to:other.id,giveId,wantId,cash,at:now(),status:'pending'};room.offers.push(offer);
 room.log.push({at:now(),text:`${actor.team} offered a deal to ${other.team}`});
 event(room,'tradeIncoming',{offerId:offer.id,from:actor.id,to:other.id,giveId,wantId});return offer;
}
export function replyTrade(room,actor,id,accept){
 if(!['transfer','final'].includes(room.stage)||now()>room.transfer.deadline)throw Error('Transfer market is closed');
 const o=room.offers.find(o=>o.id===id&&o.status==='pending');if(!o)throw Error('Offer is no longer available');
 if(actor.id!==o.to&&actor.id!==o.from)throw Error('Offer does not belong to this manager');
 if(actor.id===o.from&&accept)throw Error('Only the receiving manager can accept');
 if(!accept){o.status='rejected';return;}
 const from=managerOf(room,o.from),to=managerOf(room,o.to);
 const {a,b}=transferAllowed(room,from,to,o.giveId,o.wantId,o.cash);
 const f0=from.credits,t0=to.credits;from.squad=a;to.squad=b;refreshPlacement(from);refreshPlacement(to);from.credits-=o.cash;to.credits+=o.cash;
 if(o.cash){room.ledger.push({at:now(),type:'transfer',managerId:from.id,before:f0,delta:-o.cash,after:from.credits});room.ledger.push({at:now(),type:'transfer',managerId:to.id,before:t0,delta:o.cash,after:to.credits});}
 room.transfer.voluntary++;o.status='accepted';
 for(const pending of room.offers)if(pending.status==='pending'&&([from.id,to.id].includes(pending.from)||[from.id,to.id].includes(pending.to)))pending.status='expired';
 room.log.push({at:now(),text:`DEAL COMPLETE • ${from.team} ↔ ${to.team}`});
 event(room,'tradeDone',{offerId:o.id,from:from.id,to:to.id,giveId:o.giveId,wantId:o.wantId});
}
export function voteTransfer(room,actor){if(!['transfer','final'].includes(room.stage))throw Error('Not a transfer phase');
 if(!room.transfer.votes.includes(actor.id))room.transfer.votes.push(actor.id);
 if(room.transfer.votes.length===room.managers.length)closeTransfer(room);
}
export function randomSwap(room){
 const managers=room.managers.filter(m=>m.squad.length>0);
 if(managers.length<2){room.log.push({at:now(),text:'No legally compatible random exchange was possible — skipped'});if(room.swap)room.swap.result={skipped:true};event(room,'surpriseSwap',{skipped:true});return false;}
 const teams=[];for(let i=0;i<managers.length;i++)for(let j=i+1;j<managers.length;j++)teams.push([managers[i],managers[j]]);
 const ownedCards=managers.flatMap(m=>m.squad.map(p=>({m,p})));
 const tryExchange=(a,b,p,q)=>{
  const aa=a.squad.filter(id=>id!==p).concat(q),bb=b.squad.filter(id=>id!==q).concat(p);
  if(!feasible(aa)||!feasible(bb))return null;
  return {a,b,p,q,aa,bb};
 };
 // Rejection sampling over uniformly selected team+player pairs is unbiased among legal exchanges.
 let chosen=null;
 for(let trial=0;trial<256&&!chosen;trial++){
  const i=rnd(ownedCards.length);let j=rnd(ownedCards.length-1);if(j>=i)j++;
  const x=ownedCards[i],y=ownedCards[j];if(x.m===y.m)continue;chosen=tryExchange(x.m,y.m,x.p,y.p);
 }
 if(!chosen){
  // Exhaustive fallback ensures that "impossible" is only reported when it really is impossible.
  let eligible=0;
  for(const [a,b] of teams)for(const p of a.squad)for(const q of b.squad){
   const x=tryExchange(a,b,p,q);if(x){eligible++;if(rnd(eligible)===0)chosen=x;}
  }
 }
 if(!chosen){room.log.push({at:now(),text:'No legally compatible random exchange was possible — skipped'});if(room.swap)room.swap.result={skipped:true};event(room,'surpriseSwap',{skipped:true});return false;}
 chosen.a.squad=chosen.aa;chosen.b.squad=chosen.bb;refreshPlacement(chosen.a);refreshPlacement(chosen.b);
 if(room.swap)room.swap.result={skipped:false,from:chosen.a.id,to:chosen.b.id,giveId:chosen.p,wantId:chosen.q};event(room,'surpriseSwap',{from:chosen.a.id,to:chosen.b.id,giveId:chosen.p,wantId:chosen.q});
 room.log.push({at:now(),text:`RANDOM SWAP • ${BY_ID.get(chosen.p).name} ↔ ${BY_ID.get(chosen.q).name} • no credits moved`});
 return true;
}

export function beginSwapWarning(room,ordinal){
 if(![1,2].includes(ordinal)||room.stage!=='transfer')throw Error('Surprise swap only follows a special transfer window');
 room.stage='swap';room.swap={id:uid(),windowNo:ordinal,phase:'warning',deadline:now()+3500,result:null};
 event(room,'swapWarning',{windowNo:ordinal});
 room.log.push({at:now(),text:`SURPRISE SWAP INCOMING • Market ${ordinal} closed without a voluntary trade`});
}
export function closeTransfer(room){
 if(room.stage!=='transfer'||room.transfer?.closed)return;
 const t=room.transfer;t.closed=true;
 for(const offer of room.offers)if(offer.status==='pending')offer.status='expired';
 if(t.voluntary===0){beginSwapWarning(room,t.ordinal);return;}
 if(room.managers.every(m=>m.squad.length===16))beginLineup(room);else beginAuction(room);
}
function beginLineup(room){room.stage='lineup';room.lineupDeadline=now()+60000;
 for(const m of room.managers){if(!validateLineup(m.squad,m.lineup))m.lineup=bestLineup(m.squad).lineup;m.ready=!m.human;}
 room.log.push({at:now(),text:'SQUAD LOCK • Set your starting XI and confirm lineup'});
 if(room.managers.every(m=>m.ready))startTournament(room);
}
export function setLineup(room,actor,lineup){if(room.stage!=='lineup')throw Error('Lineups are locked outside squad preparation');
 if(!validateLineup(actor.squad,lineup))throw Error('Choose 11 different footballers that you own');
 actor.lineup=lineup;actor.ready=false;
}
export function confirmLineup(room,actor){if(room.stage!=='lineup')throw Error('Not in lineup selection');
 if(!validateLineup(actor.squad,actor.lineup))throw Error('Select eleven legally positioned starters first');
 actor.ready=true;if(room.managers.every(m=>m.ready))startTournament(room);
}
function shuffle(array){for(let i=array.length-1;i>0;i--){const j=rnd(i+1);[array[i],array[j]]=[array[j],array[i]];}return array;}
export function rematch(room,actor){
 if(room.stage!=='done'||actor.id!==room.hostId)throw Error('Only the host may start a rematch after the championship');
 if(room.managers.filter(m=>m.human).some(m=>!m.online))throw Error('All human managers must reconnect before the rematch');
 room.managers=room.managers.filter(m=>m.human);
 room.stage='lobby';room.auctionNo=0;room.auction=null;room.transfer=null;room.unsold={};room.history=[];room.log=[];room.swap=null;room.swapCompleted=[];room.transferOpened=[];room.events=[];
 room.ledger=[];room.offers=[];room.bracket=[];room.remainingTeams=[];room.nextRound=[];room.roundPairs=[];room.pairIndex=0;room.match=null;room.champion=null;
 for(const m of room.managers){m.ready=true;m.credits=0;m.squad=[];m.lineup=[];m.subbedOut=[];m.subsUsed=0;m.tactic='Balanced';m.eliminated=false;m.draftWins=0;m.formation='4-3-3';m.pendingTactics=null;}
 start(room,actor);
}
export function startTournament(room){
 if(room.managers.some(m=>m.squad.length!==16||!validateLineup(m.squad,m.lineup)))throw Error('Cannot begin tournament without complete legal squads');
 for(const m of room.managers){m.eliminated=false;m.subbedOut=[];m.subsUsed=0;m.tactic='Balanced';}
 room.stage='tournament';room.remainingTeams=shuffle(room.managers.map(m=>m.id));room.nextRound=[];room.bracket=[];beginRound(room);
}
function beginRound(room){
 if(room.remainingTeams.length===1){room.stage='done';room.champion=room.managers.length===1?null:room.remainingTeams[0];room.match=null;room.log.push({at:now(),text:room.champion?`CHAMPIONS • ${managerOf(room,room.champion).team}`:'SOLO SQUAD-BUILDING PRACTICE COMPLETE'});return;}
 const teams=room.remainingTeams.slice();room.remainingTeams=[];room.nextRound=[];room.pairIndex=0;
 room.roundPairs=[];
 // Bye recipient advances automatically; no fictional match recorded.
 if(teams.length%2===1){const bye=teams.pop();room.nextRound.push(bye);room.log.push({at:now(),text:`BYE • ${managerOf(room,bye).team} advances`});}
 for(let i=0;i<teams.length;i+=2)room.roundPairs.push([teams[i],teams[i+1]]);
 room.bracket.push({round:room.bracket.length+1,pairs:room.roundPairs.map(pair=>({teams:pair,winner:null,score:null}))});
 beginMatch(room);
}
function beginMatch(room){
 const pair=room.roundPairs[room.pairIndex];if(!pair){room.remainingTeams=shuffle(room.nextRound.slice());beginRound(room);return;}
 for(const id of pair){const m=managerOf(room,id);m.subsUsed=0;m.subbedOut=[];m.tactic='Balanced';}
 const startTime=now(),matchId=uid(),managers=pair.map(id=>managerOf(room,id));
 const sim=newSimulation(managers,matchId);
 room.stage='match';room.match={id:matchId,teams:pair,half:1,score:[0,0],events:sim.events,goals:[],deadline:startTime+27000,halfStart:startTime,lastPulse:0,halftimeReady:[],statistics:sim.statistics,live:{step:sim.step,players:sim.players,ball:sim.ball,possession:sim.possession,holder:sim.holder,action:'kickoff'},extra:false,penalties:null,sim};
 room.log.push({at:now(),text:`KICKOFF • ${managerOf(room,pair[0]).team} vs ${managerOf(room,pair[1]).team}`});
}
export function lineStrength(m){
 const slots=teamSlots(m),ids=m.lineup.map(id=>BY_ID.get(id));
 const vals=slots.map((slot,i)=>({slot,rating:positionRating(ids[i],slot),p:ids[i]}));
 const mean=(group,attribute)=>{
  const selected=vals.filter(x=>GROUPS[x.slot]===group);if(!selected.length)return 40;
  return selected.reduce((sum,x)=>sum+(.67*x.rating+.33*(x.p?.attributes?.[attribute]||50)),0)/selected.length;
 };
 const mid=mean('MID','MID'),forward=mean('ATT','ATT'),def=mean('DEF','DEF'),gk=vals[0]?.rating||20;
 const tactics=m.tactic==='Attack'?{att:1.15,def:.88}:m.tactic==='Defend'?{att:.87,def:1.14}:{att:1,def:1};
 const perkBonus=ids.filter(p=>p?.perk).length*.2;
 return {attack:(forward*.65+mid*.35+perkBonus)*tactics.att,defense:(def*.68+gk*.32+perkBonus)*tactics.def,keeper:gk};
}
// Server steps gameplay in fixed simulated intervals; clients ONLY render the result.
// Goals, saves, shots and stats are generated by the same deterministic action log.
function pulse(room){const match=room.match;if(!match)return;
 const managers=match.teams.map(id=>managerOf(room,id));
 const period=match.half;
 stepSimulation(match.sim,managers,BY_ID,positionRating,period);
 validateSimulation(match.sim);
 match.score=[...match.sim.score];match.events=match.sim.events;match.goals=match.sim.goals;
 match.statistics=match.sim.statistics;
 match.live={step:match.sim.step,players:match.sim.players.map(p=>({...p})),ball:{...match.sim.ball},possession:match.sim.possession,holder:match.sim.holder,action:match.sim.currentAction};
 match.spot={...match.sim.ball};match.simulatedMinute=match.sim.minute;
}
function finishMatch(room){const match=room.match;if(room.stage!=='match')return;
 validateSimulation(match.sim);
 if(match.score[0]===match.score[1]){
  const managers=match.teams.map(id=>managerOf(room,id));
  const shootout=resolvePenalties(match.sim,managers,BY_ID,positionRating);
  match.penalties=shootout;
 }
 const winner=match.penalties?match.teams[match.penalties.winner]:match.teams[match.score[0]>match.score[1]?0:1];
 const round=room.bracket.at(-1);round.pairs[room.pairIndex].winner=winner;round.pairs[room.pairIndex].score=[...match.score];round.pairs[room.pairIndex].penalties=match.penalties;
 round.pairs[room.pairIndex].statistics=match.statistics;
 const loser=match.teams.find(id=>id!==winner);managerOf(room,loser).eliminated=true;
 match.winner=winner;match.goals=match.sim.goals;
 room.log.push({at:now(),text:`FULL TIME • ${managerOf(room,winner).team} advance (${match.score.join('–')})`});
 room.stage='fulltime';match.fullTimeDeadline=now()+6000;
}
function advanceTournament(room){if(room.stage!=='fulltime')return;
 room.nextRound.push(room.match.winner);room.pairIndex++;beginMatch(room);
}
export function substitution(room,actor,slot,inId){
 const mt=room.match;if(room.stage!=='halftime'||!mt?.teams.includes(actor.id))throw Error('Substitutions are halftime only');
 if(!Number.isInteger(slot)||slot<0||slot>=11||!actor.squad.includes(inId))throw Error('Invalid substitution');
 if(actor.subsUsed>=5)throw Error('Five-substitution limit reached');
 if(actor.lineup.includes(inId))throw Error('Incoming player is already on the pitch');
 if(actor.subbedOut.includes(inId))throw Error('Substituted players may not return');
 // An unnatural position is permitted, but suffers a severe positionRating penalty.
 const prior=actor.lineup[slot];actor.subbedOut.push(prior);actor.lineup[slot]=inId;actor.subsUsed++;
 mt.sim.actionLog.push({type:'sub',team:mt.teams.indexOf(actor.id),playerId:inId,outId:prior,minute:45,step:mt.sim.step});
 mt.sim.statistics=computeStats(mt.sim.actionLog);mt.statistics=mt.sim.statistics;
 mt.events.push({minute:45,type:'sub',team:actor.team,text:`${actor.team} • ${BY_ID.get(inId).name} comes on`,at:now()});
}
export function tactic(room,actor,value){if(room.stage!=='halftime'||!room.match?.teams.includes(actor.id))throw Error('Tactics may change at halftime only');
 if(!['Attack','Balanced','Defend'].includes(value))throw Error('Unknown tactic');actor.tactic=value;
}
export function halfReady(room,actor){if(room.stage!=='halftime'||!room.match?.teams.includes(actor.id))throw Error('No halftime pause available');
 if(!room.match.halftimeReady.includes(actor.id))room.match.halftimeReady.push(actor.id);
 if(room.match.halftimeReady.length===room.match.teams.length)endHalftime(room);
}
function endHalftime(room){const m=room.match;if(room.stage!=='halftime')return;
 room.stage='match';m.half=2;m.halfStart=now();m.deadline=now()+27000;m.lastPulse=0;
}
export function tick(room){const time=now(),m=room.match;
 if(room.stage==='swap'&&room.swap){
  const swap=room.swap;if(time<swap.deadline)return false;
  if(swap.phase==='warning'){
   randomSwap(room);swap.phase='result';swap.deadline=time+4500;
   return true;
  }
  if(swap.phase==='result'){
   room.swap=null;
   if(room.managers.every(m=>m.squad.length===16))beginLineup(room);else beginAuction(room);
   return true;
  }
 }
 if(room.stage==='auction'){
  const a=room.auction;if(!a)return;
  if(time>=a.deadline){closeAuction(room);return true;}
  if(time>=a.botAt){a.botAt=time+range(3300,6700);
   const card=BY_ID.get(a.cardId);const budgetRatio=room.settings.difficulty==='Easy'?.82:room.settings.difficulty==='Expert'?1.27:1.03;
   const bots=room.managers.filter(x=>x.aiControl&&!a.passed.includes(x.id));
   for(const bot of bots){
    if(bot.squad.length===16||a.leader===bot.id){if(!a.votes.includes(bot.id))a.votes.push(bot.id);continue;}
    const min=a.highestBid?a.highestBid+10:10;
    const ceiling=Math.round((card.rating-70)*6*budgetRatio+20);
    if(min<=Math.min(maxBid(room,bot),ceiling)&&feasible([...bot.squad,card.id])&&Math.random()<(room.settings.difficulty==='Expert'?.77:.57)){
     try{placeBid(room,bot,min);}catch{}
    }else{if(!a.votes.includes(bot.id))a.votes.push(bot.id);}
   }
   if(a.votes.length===room.managers.length){closeAuction(room);return true;}return true;
  }
 }
 if(room.stage==='transfer'||room.stage==='final'){
  const t=room.transfer;if(time>=t.deadline){closeTransfer(room);return true;}
  if(time>=t.botAt){t.botAt=time+5500;
   for(const bot of room.managers.filter(x=>x.aiControl)){
    // Bots can propose one legal deal per window, and human recipients choose whether to accept.
    if(!t.proposedBy.includes(bot.id)&&bot.squad.length&&Math.random()<.22){
     const partners=room.managers.filter(x=>x.id!==bot.id&&x.squad.length);
     if(partners.length){const other=partners[rnd(partners.length)];
      const owned=bot.squad.slice().sort(()=>Math.random()-.5);
      const wanted=other.squad.slice().sort(()=>Math.random()-.5);
      let sent=false;
      for(const giveId of owned.slice(0,5)){for(const wantId of wanted.slice(0,5)){
       if(sent)break;if(BY_ID.get(giveId).position!==BY_ID.get(wantId).position)continue;
       try{offerTrade(room,bot,{to:other.id,giveId,wantId,cash:0});sent=true;break;}catch{}
      }if(sent)break;}
      if(sent)t.proposedBy.push(bot.id);
     }
    }
    for(const offer of room.offers.filter(o=>o.to===bot.id&&o.status==='pending')){
     const from=managerOf(room,offer.from),mine=offer.wantId?BY_ID.get(offer.wantId):null,theirs=offer.giveId?BY_ID.get(offer.giveId):null;
     const favorable=(theirs?.rating||0)-(mine?.rating||0)+offer.cash*.07;
     try{replyTrade(room,bot,offer.id,favorable>= (room.settings.difficulty==='Expert'?4:-5));}catch{offer.status='expired';}
    }
    if(!t.votes.includes(bot.id))t.votes.push(bot.id);
   }
   if(t.votes.length===room.managers.length){closeTransfer(room);return true;}return true;
  }
 }
 if(room.stage==='lineup'&&time>=room.lineupDeadline){for(const x of room.managers){x.lineup=validateLineup(x.squad,x.lineup)?x.lineup:bestLineup(x.squad).lineup;x.ready=true;}startTournament(room);return true;}
 if(room.stage==='match'&&m){
  if(room.managers.some(x=>x.pendingTactics)){applyPendingTactics(room);return true;}
  // Real-time-independent fixed steps: 90 per half, 20 for extra time.
  const target=m.half===1?Math.min(90,Math.floor((time-m.halfStart)/300)):
   m.half===2?90+Math.min(90,Math.floor((time-m.halfStart)/300)):
   180+Math.min(20,Math.floor((time-m.halfStart)/300));
  if(m.sim.step<target){
   // Catch up after suspension/reconnection without changing deterministic outcomes.
   while(m.sim.step<target)pulse(room);
   if(time<m.deadline)return true;
  }
  if(time>=m.deadline){
   if(m.half===1){while(m.sim.step<90)pulse(room);room.stage='halftime';m.halftimeDeadline=time+25000;m.halftimeReady=[];for(const id of m.teams){const x=managerOf(room,id);if(x.aiControl)m.halftimeReady.push(id);}return true;}
   if(m.half===2){while(m.sim.step<180)pulse(room);if(m.score[0]===m.score[1]){m.half=3;m.extra=true;m.halfStart=time;m.deadline=time+6000;return true;}}
   if(m.half===3)while(m.sim.step<200)pulse(room);
   finishMatch(room);return true;
  }
 }
 if(room.stage==='fulltime'&&time>=m.fullTimeDeadline){advanceTournament(room);return true;}
 if(room.stage==='halftime'){
  if(time>=m.halftimeDeadline){endHalftime(room);return true;}
  if(m.halftimeReady.length===m.teams.length){endHalftime(room);return true;}
 }
 return false;
}
export function verifyRoom(room){const owned=room.managers.flatMap(m=>m.squad),uids=new Set(owned);
 if(uids.size!==owned.length)throw Error('Duplicate card ownership detected');
 for(const m of room.managers){if(m.squad.length>16||m.credits<0||!Number.isSafeInteger(m.credits)||!FORMATIONS[m.formation||'4-3-3'])throw Error('Roster or credit integrity violated');if(!m.squad.every(id=>BY_ID.has(id)))throw Error('Unknown owned card');if(m.lineup?.length&& !validPlacement(m.squad,m.lineup))throw Error('Tactical board contains an unowned or duplicated player');if(!feasible(m.squad))throw Error('Uncompletable roster detected');}
 if(room.stage==='lobby'&&owned.length)throw Error('Lobby clubs must start with zero players');
 const acquired=new Set((room.ledger||[]).filter(e=>e.type==='auction').map(e=>e.cardId));
 if(owned.some(id=>!acquired.has(id)))throw Error('Player ownership without a recorded winning auction');
 return true;
}
