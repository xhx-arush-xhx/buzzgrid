import http from 'node:http';
import { promises as fs, readFileSync, existsSync } from 'node:fs';
import { join, extname, resolve, dirname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import {upgrade} from './ws.mjs';
import {CARDS,BY_ID,createRoom,join as joinRoom,managerOf,publicRoom,start,placeBid,passAuction,voteAuction,offerTrade,replyTrade,voteTransfer,setLineup,confirmLineup,substitution,tactic,halfReady,rematch,tick,verifyRoom,sanitize,now,setFormation,positionRating,SLOTS,FORMATIONS} from './engine.mjs';
import {artSVG} from './art.mjs';
import {thumbnailURL,originalURL,catalogIntegrity} from './photo.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
// In cloud hosting, put mutable room state on an attached persistent volume.
const volumeRoot=process.env.RAILWAY_VOLUME_MOUNT_PATH||process.env.PERSISTENT_DATA_DIR||'';
const sessionsPath=process.env.SESSIONS_PATH||(volumeRoot?join(volumeRoot,'sessions.json'):join(root,'data/sessions.json'));
const staticDir=join(root,'public');
const photoCatalog=JSON.parse(readFileSync(join(root,'data/photo_catalog.json'),'utf8'));
const PHOTO_BY_ID=new Map(photoCatalog.map(x=>[x.id,x]));
const PHOTO_AUDIT=catalogIntegrity(CARDS,photoCatalog);
if(!PHOTO_AUDIT.ok)throw new Error('Incorrect photo-to-player mapping: '+PHOTO_AUDIT.errors.slice(0,5).join('; '));
console.log(`Player photo mapping: ${PHOTO_AUDIT.withPhotos}/1000 linked, ${PHOTO_AUDIT.missingPhotos} missing, ${PHOTO_AUDIT.manualReview} needing review`);
// Host-managed portrait overrides are keyed by immutable footballer IDs.
const imageDir=process.env.PLAYER_IMAGE_DIR||(volumeRoot?join(volumeRoot,'player-images'):join(root,'data/player-images'));
const imageIndexPath=join(imageDir,'index.json');
let imageIndex={};
try{imageIndex=JSON.parse(readFileSync(imageIndexPath,'utf8'));}catch{}
const mimeForExt={png:'image/png',jpg:'image/jpeg',webp:'image/webp'};
const uploadedURL=p=>imageIndex[p.id]?`/api/image/${p.id}?v=${encodeURIComponent(imageIndex[p.id].version)}`:null;
const imageMetadata=p=>{const entry=PHOTO_BY_ID.get(p.id),custom=uploadedURL(p);
const original=custom||originalURL(entry),image=custom||thumbnailURL(entry,360)||p.image;
return {image,imageThumb:custom||thumbnailURL(entry,160)||p.image,imageOriginal:original||'',imageFallback:p.image,imageStatus:custom?'host_uploaded':(original?entry.status:'illustration_fallback'),imageSource:entry?.sourceUrl||null,imageLicense:entry?.license||null,imageAttribution:entry?.attribution||null,reviewRequired:custom?false:entry?.reviewRequired!==false};};
async function readLimited(req,limit){
 const chunks=[];let size=0;
 for await(const chunk of req){size+=chunk.length;if(size>limit)throw Error('Image exceeds the 2 MB limit');chunks.push(chunk);}
 return Buffer.concat(chunks);
}
function imageType(b){
 if(b.length>=8 && b.subarray(0,8).equals(Buffer.from('89504e470d0a1a0a','hex')))return 'png';
 if(b.length>=3 && b.subarray(0,3).equals(Buffer.from('ffd8ff','hex')))return 'jpg';
 if(b.length>=12 && b.toString('ascii',0,4)==='RIFF' && b.toString('ascii',8,12)==='WEBP')return 'webp';
 return null;
}
function assertUploadHost(req){
 const origin=req.headers.origin;if(origin && new URL(origin).host!==req.headers.host)throw Error('Invalid origin');
 const room=rooms.get(String(req.headers['x-room-code']||'').toUpperCase());
 const manager=room?.managers.find(m=>m.human&&m.id===room.hostId);
 if(!manager || !manager.online || !manager.token || manager.token!==req.headers['x-manager-token'])throw Error('Only the connected room host can change player pictures');
 return manager;
}
function broadcastImage(id,image){
 for(const entry of sockets)entry.ws.send({type:'imageUpdated',id,image});
}

const rooms=new Map(), sockets=new Set();
if(existsSync(sessionsPath)){
 try{for(const room of JSON.parse(readFileSync(sessionsPath,'utf8'))){
  for(const m of room.managers){if(m.human){m.online=false;m.disconnectedAt=now();m.aiControl=true;}}
  if(room.stage!=='done')rooms.set(room.code,room);
 }console.log('Recovered',rooms.size,'rooms');}catch(e){console.error('Could not restore rooms:',e.message);}
}
let flushTimer=null,writeChain=Promise.resolve();
function persist(){if(flushTimer)return;
 flushTimer=setTimeout(()=>{flushTimer=null;const snapshot=JSON.stringify([...rooms.values()]);
  writeChain=writeChain.then(async()=>{await fs.mkdir(dirname(sessionsPath),{recursive:true});const file=sessionsPath+'.tmp';await fs.writeFile(file,snapshot);await fs.rename(file,sessionsPath);}).catch(e=>console.error('Persistence error:',e.message));
 },400);
 flushTimer.unref();
}
async function gracefulExit(){clearTimeout(flushTimer);flushTimer=null;
 try{await writeChain;await fs.mkdir(dirname(sessionsPath),{recursive:true});const file=sessionsPath+'.tmp';await fs.writeFile(file,JSON.stringify([...rooms.values()]));await fs.rename(file,sessionsPath);}catch(e){console.error('Final save failure:',e.message);}
 server.close();process.exit(0);
}
process.on('SIGTERM',gracefulExit);process.on('SIGINT',gracefulExit);
function sendState(room){room.updatedAt=now();
 const data=JSON.stringify({type:'state',room:publicRoom(room)});
 for(const entry of sockets)if(entry.room===room)entry.ws.send(data);
 persist();}
function notice(entry,message){entry.ws.send({type:'error',message});}
function notify(entry){if(entry.room){entry.ws.send({type:'identity',id:entry.actor?.id,token:entry.actor?.token,code:entry.room.code});entry.ws.send({type:'state',room:publicRoom(entry.room)});}}
function requireActor(entry){if(!entry.room||!entry.actor)throw Error('Join a room before playing');
 const actual=managerOf(entry.room,entry.actor.id);if(!actual||!actual.human)throw Error('Not authorized for this manager');return actual;}
function dispatch(entry,msg){if(!msg||typeof msg.type!=='string')throw Error('Unknown action');
 const t=msg.type,p=msg.payload||{};let r=entry.room;
 if(t==='create'){
  if(r)throw Error('Leave the current room first');
  const {room,host}=createRoom(p,p.name||'Manager');while(rooms.has(room.code))room.code=room.id.slice(0,6).toUpperCase();rooms.set(room.code,room);
  entry.room=room;entry.actor=host;notify(entry);sendState(room);return;
 }
 if(t==='join'){
  if(r)throw Error('Leave the current room first');
  r=rooms.get(String(p.code||'').toUpperCase());if(!r)throw Error('Room not found');
  let m=null;
  if(p.token)m=r.managers.find(x=>x.human&&x.token===p.token);
  if(!m)m=joinRoom(r,p.name||'Manager');
  for(const conn of sockets){if(conn.actor?.id===m.id&&conn.room===r){conn.ws.close();}}
  m.online=true;m.disconnectedAt=null;m.aiControl=false;entry.room=r;entry.actor=m;notify(entry);sendState(r);return;
 }
 if(t==='leave'){
  const a=requireActor(entry);if(r.stage!=='lobby')throw Error('Active games are preserved; close the tab to disconnect and rejoin');
  if(a.id===r.hostId){for(const conn of sockets){if(conn.room===r){conn.ws.send({type:'error',message:'Room closed by host'});conn.room=null;conn.actor=null;}}rooms.delete(r.code);persist();return;}
  r.managers=r.managers.filter(m=>m.id!==a.id);entry.room=null;entry.actor=null;sendState(r);return;
 }
 const a=requireActor(entry);
 switch(t){
  case 'ready':if(r.stage!=='lobby')throw Error('Lobby closed');a.ready=Boolean(p.ready);break;
  case 'configure':{
   if(r.stage!=='lobby'||a.id!==r.hostId)throw Error('Only host can update lobby settings');
   const humans=Number(p.humans),bots=Number(p.bots);
   if(!Number.isInteger(humans)||humans<1||humans>8||humans<r.managers.filter(x=>x.human).length)throw Error('Human capacity must be 1–8 and cannot exclude already joined managers');
   if(!Number.isInteger(bots)||bots<0||humans+bots>8)throw Error('The room supports at most eight total managers');
   if(!['Easy','Normal','Expert'].includes(p.difficulty))throw Error('Unknown bot difficulty');
   r.settings={...r.settings,humans,bots,difficulty:p.difficulty};r.title=sanitize(p.title||r.title);break;
  }
  case 'rename':if(r.stage!=='lobby')throw Error('Names locked after start');a.name=sanitize(p.name);a.team=sanitize(p.team);break;
  case 'start':start(r,a);break;
  case 'bid':placeBid(r,a,Number(p.amount));break;
  case 'pass':passAuction(r,a);break;
  case 'endAuction':voteAuction(r,a);break;
  case 'offer':offerTrade(r,a,p);break;
  case 'reply':replyTrade(r,a,String(p.id),Boolean(p.accept));break;
  case 'endTransfers':voteTransfer(r,a);break;
  case 'lineup':setLineup(r,a,p.lineup);break;
  case 'formation':setFormation(r,a,p.lineup,p.shape);break;
  case 'confirmLineup':confirmLineup(r,a);break;
  case 'sub':substitution(r,a,Number(p.slot),String(p.inId));break;
  case 'tactic':tactic(r,a,String(p.value));break;
  case 'halfReady':halfReady(r,a);break;
  case 'rematch':rematch(r,a);break;
  default:throw Error('Unknown game action: '+t);
 }
 verifyRoom(r);sendState(r);
}
const ALL_ROLES=[...new Set(Object.values(FORMATIONS).flatMap(x=>x.slots))];
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.json':'application/json; charset=utf-8','.png':'image/png','.ico':'image/x-icon'};
const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://localhost');
  if(url.pathname==='/api/photo-audit'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(PHOTO_AUDIT));return;}
  if(url.pathname==='/api/health'){res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({ok:true,players:CARDS.length,rooms:rooms.size}));return;}
  if(url.pathname==='/api/catalog'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-cache'});res.end(JSON.stringify(CARDS.map(p=>({id:p.id,name:p.name,position:p.position,secondary:p.secondary,rating:p.rating,basePrice:p.basePrice,attributes:p.attributes,perk:p.perk,...imageMetadata(p),ratingReview:p.ratingReview,recognitionReview:p.recognitionReview,recognitionPriority:p.recognitionPriority,awardEvidence:p.awardEvidence,positionSource:p.positionSource,ratingSource:p.ratingSource,attributesSource:p.attributesSource,positionRatings:Object.fromEntries(ALL_ROLES.map(slot=>[slot,positionRating(p,slot)])),era:p.era}))));return;}
  if(url.pathname==='/api/players'){
   const q=(url.searchParams.get('q')||'').toLowerCase(),position=url.searchParams.get('position')||'',offset=Math.min(1000,Math.max(0,+url.searchParams.get('offset')||0)),limit=Math.min(60,Math.max(1,+url.searchParams.get('limit')||24));
   const found=CARDS.filter(p=>(!q||p.name.toLowerCase().includes(q))&&(!position||p.position===position));
   res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'public, max-age=30'});res.end(JSON.stringify({total:found.length,results:found.slice(offset,offset+limit).map(p=>({...p,...imageMetadata(p),ratingReview:p.ratingReview,recognitionReview:p.recognitionReview,recognitionPriority:p.recognitionPriority,awardEvidence:p.awardEvidence,positionSource:p.positionSource,ratingSource:p.ratingSource,attributesSource:p.attributesSource,positionRatings:Object.fromEntries(ALL_ROLES.map(slot=>[slot,positionRating(p,slot)]))}))}));return;
  }
  const playerImage=url.pathname.match(/^\/api\/image\/(FC\d{4})$/);
  if(playerImage && req.method==='GET'){
   const record=imageIndex[playerImage[1]];
   if(!record){res.writeHead(404);res.end('No portrait uploaded');return;}
   const file=await fs.readFile(join(imageDir,record.file));
   res.writeHead(200,{'Content-Type':mimeForExt[record.ext], 'X-Content-Type-Options':'nosniff','Cache-Control':'public,max-age=86400'});res.end(file);return;
  }
  const uploadImage=url.pathname.match(/^\/api\/image\/(FC\d{4})$/);
  if(uploadImage && req.method==='POST'){
   const id=uploadImage[1];
   if(!BY_ID.has(id)){res.writeHead(404);res.end('Unknown player');return;}
   assertUploadHost(req);
   const len=Number(req.headers['content-length']);
   if(!Number.isInteger(len)||len<10||len>2*1024*1024){res.writeHead(413);res.end('Image must be under 2 MB');return;}
   const body=await readLimited(req,2*1024*1024);
   const ext=imageType(body);
   if(!ext||req.headers['content-type']!==mimeForExt[ext]){res.writeHead(415);res.end('Upload a valid JPG, PNG, or WebP picture');return;}
   await fs.mkdir(imageDir,{recursive:true});
   const version=Date.now().toString(36),file=`${id}-${version}.${ext}`;
   await fs.writeFile(join(imageDir,file),body,{flag:'wx'});
   const previous=imageIndex[id];
   imageIndex[id]={file,ext,version};
   const tmp=imageIndexPath+'.tmp';
   await fs.writeFile(tmp,JSON.stringify(imageIndex,null,2));await fs.rename(tmp,imageIndexPath);
   if(previous?.file && previous.file!==file)await fs.unlink(join(imageDir,previous.file)).catch(()=>{});
   const image=`/api/image/${id}?v=${version}`;
   broadcastImage(id,image);
   res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({ok:true,id,image}));return;
  }
  if(url.pathname.startsWith('/api/art/')){
   const id=url.pathname.slice(9).replace('.svg',''),art=artSVG(id);
   if(!art){res.writeHead(404);res.end('Not found');return;}
   res.writeHead(200,{'Content-Type':'image/svg+xml; charset=utf-8','Cache-Control':'public, max-age=2592000, immutable','X-Content-Type-Options':'nosniff'});res.end(art);return;
  }
  const rel=url.pathname==='/'?'/index.html':url.pathname;
  const path=resolve(staticDir,'.'+rel);
  if(!path.startsWith(staticDir+sep)&&path!==join(staticDir,'index.html')){res.writeHead(403);res.end();return;}
  const file=await fs.readFile(path);
  res.writeHead(200,{'Content-Type':types[extname(path)]||'application/octet-stream','Cache-Control':'public, max-age=300','X-Content-Type-Options':'nosniff'});res.end(file);
 }catch(e){
  const upload=req.method==='POST' && req.url?.startsWith('/api/image/');
  const status=upload?(e.message?.includes('host')||e.message?.includes('origin')?403:e.message?.includes('2 MB')?413:400):404;
  res.writeHead(status,{'Content-Type':'text/plain; charset=utf-8'});res.end(upload?(status===403?'Not authorized':e.message):'Not found');
 }
});
server.on('upgrade',(req,socket,head)=>{
 if(req.headers.origin){try{const origin=new URL(req.headers.origin);if(origin.host!==req.headers.host){socket.destroy();return;}}catch{socket.destroy();return;}}
 const entry={ws:null,room:null,actor:null};
 const ws=upgrade(req,socket,head,(message)=>{try{dispatch(entry,message);}catch(e){notice(entry,e.message);}},()=>{
  sockets.delete(entry);if(!entry.room||!entry.actor)return;
  const stillOnline=[...sockets].some(x=>x.room===entry.room&&x.actor?.id===entry.actor.id);
  if(!stillOnline){entry.actor.online=false;entry.actor.disconnectedAt=now();sendState(entry.room);}
 });
 if(ws){entry.ws=ws;sockets.add(entry);ws.send({type:'connected',count:CARDS.length});}
});
const timer=setInterval(()=>{
 for(const room of rooms.values()){
  let changed=false;
  for(const m of room.managers)if(m.human&&!m.online&&!m.aiControl&&m.disconnectedAt&&now()-m.disconnectedAt>8000){m.aiControl=true;changed=true;room.log.push({at:now(),text:`Temporary AI now controls ${m.team} until reconnection`});}
  try{changed=tick(room)||changed;if(changed){verifyRoom(room);sendState(room);}}catch(e){console.error('GAME FAULT',room.code,e);room.log.push({at:now(),text:`Engine warning: ${e.message}`});sendState(room);}
 }
},300);timer.unref();
setInterval(()=>{for(const entry of sockets)if(entry.room)entry.ws.send({type:'clock',serverTime:now()});},1000).unref();
const port=Number(process.env.PORT)||3000;
server.listen(port,'0.0.0.0',()=>console.log(`FOOTBALL AUCTION ROYALE http://localhost:${port} • ${CARDS.length} cards`));
