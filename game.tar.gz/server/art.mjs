import {BY_ID} from './engine.mjs';
function xml(s){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');}
const palettes=[['#E8B870','#64315B','#9B58D0'],['#9FE3DE','#153F58','#227B8B'],['#F4D2B5','#4E405D','#AC6481'],['#D4EB91','#204638','#55A769'],['#BBD5FE','#2C3868','#5660AD'],['#FFD4A3','#604533','#B97047']];
function hash(s){let n=2166136261;for(const x of s){n=Math.imul(n^x.charCodeAt(0),16777619);}return n>>>0;}
export function artSVG(id){const p=BY_ID.get(id);if(!p)return null;
 const n=hash(p.id+p.name),[light,dark,accent]=palettes[n%palettes.length];
 const skin=['#B56D47','#D99566','#925738','#E3B08A','#68412F','#BC825C'][Math.floor(n/7)%6];
 const hair=['#151922','#30241C','#69482B','#1C262D'][Math.floor(n/11)%4];
 const hairShape=(n%5===0)?'<path d="M133 128 Q120 77 184 67 Q258 68 254 129 L236 115 Q206 86 161 109Z"/>':
 (n%5===1)?'<path d="M134 131Q120 83 161 76Q209 59 249 92L250 128L233 111Q199 121 167 100Z"/>':
 (n%5===2)?'<path d="M132 134Q123 85 160 79Q220 53 245 98L246 128Q218 114 207 99Q180 122 145 112Z"/>':
 '<path d="M134 128Q125 91 150 78Q185 57 221 72Q247 84 249 126Q220 96 191 100Q169 113 142 107Z"/>';
 const trim=n%3===0?'#E6C978':'#F0F0F1';
 const num=String(p.rank).padStart(2,'0');
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 380 475" role="img" aria-label="Stylized original football illustration for ${xml(p.name)} — not an authentic likeness">
 <defs><linearGradient id="bg" x2=".8" y2="1"><stop stop-color="${dark}"/><stop offset="1" stop-color="#0B1427"/></linearGradient><radialGradient id="halo"><stop stop-color="${accent}" stop-opacity=".9"/><stop offset="1" stop-color="${accent}" stop-opacity="0"/></radialGradient><linearGradient id="shirt" x2="1" y2="1"><stop stop-color="${accent}"/><stop offset="1" stop-color="${dark}"/></linearGradient></defs>
 <rect width="380" height="475" fill="url(#bg)"/><circle cx="205" cy="196" r="165" fill="url(#halo)" opacity=".7"/><path d="M-40 410L380 80M35 505L415 200" stroke="${light}" stroke-opacity=".12" stroke-width="18"/><path d="M0 366Q190 320 380 380" stroke="${light}" stroke-opacity=".2" stroke-width="2" fill="none"/>
 <g opacity=".25" stroke="${light}" fill="none"><circle cx="196" cy="210" r="115"/><circle cx="196" cy="210" r="139"/><path d="M15 240H365"/></g>
 <path d="M25 480L36 340Q57 308 129 291L162 275H217L255 292Q320 309 340 346L368 480Z" fill="url(#shirt)" stroke="${trim}" stroke-opacity=".35" stroke-width="3"/>
 <path d="M130 293L160 312L190 337L218 312L254 294" stroke="${trim}" stroke-width="11" fill="none"/><path d="M166 266L162 300L190 320L222 300L216 267" fill="${skin}"/>
 <ellipse cx="189" cy="183" rx="59" ry="80" fill="${skin}"/><path d="M133 128Q119 119 126 106Q117 75 153 69Q204 45 239 76Q262 103 250 136" fill="${hair}"/>
 <g fill="${hair}">${hairShape}</g><path d="M156 183Q166 177 180 184M200 184Q216 177 228 184" stroke="${hair}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M177 230Q192 236 210 228" fill="none" stroke="#5B2E25" stroke-width="3" stroke-linecap="round"/>
 <path d="M188 187l-3 21l7 3" stroke="#5B2E25" fill="none" stroke-opacity=".5" stroke-width="2"/>
 <rect x="18" y="18" width="82" height="28" rx="5" fill="#091321" fill-opacity=".6" stroke="${light}" stroke-opacity=".5"/><text x="59" y="37" text-anchor="middle" font-family="Arial,sans-serif" font-size="13" font-weight="800" fill="white" letter-spacing="2">${xml(p.position)}</text>
 <text x="190" y="424" text-anchor="middle" font-size="50" font-weight="900" font-family="Arial,sans-serif" fill="white" opacity=".1">${num}</text>
 <path d="M0 443H380" stroke="${trim}" stroke-width="3" stroke-opacity=".48"/><text x="24" y="463" fill="${light}" font-family="Arial,sans-serif" font-size="10" font-weight="800" letter-spacing="2">ROYALE // PRIME EDITION</text><text x="350" y="463" fill="${light}" font-family="Arial,sans-serif" text-anchor="end" font-size="10">${xml(p.id)}</text>
 </svg>`;
}
