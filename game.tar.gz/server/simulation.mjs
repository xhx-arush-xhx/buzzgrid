// Deterministic, fixed-step, EVENT-DRIVEN two-dimensional football simulation.
// Attribute inputs are the project's explicitly labelled game estimates, not verified scouting statistics.
// Neither scores nor presentation events are chosen independently of the simulated action log.
import {formationCoordinates,formationSlots} from '../public/formations.mjs';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const distance=(a,b)=>Math.hypot(a.x-b.x,(a.y-b.y)*.85);
export function seedFrom(value){let h=2166136261;for(const ch of String(value)){h=Math.imul(h^ch.charCodeAt(0),16777619);}return h>>>0||1;}
function random(s){let x=s.seed>>>0;x^=x<<13;x^=x>>>17;x^=x<<5;s.seed=x>>>0;return (s.seed>>>0)/4294967296;}
function normalGroup(pos){return pos==='GK'?'GK':['RB','LB','CB','RWB','LWB'].includes(pos)?'DEF':['CDM','CM','CAM','LM','RM'].includes(pos)?'MID':'ATT';}
function attr(p,key){const a=p?.attributes||{};if(key==='PACE')return clamp(Math.round((a.ATT||65)*.48+(a.MID||65)*.2+(p?.rating||75)*.32),30,97);return clamp(Number(a[key]??55),20,99);}
function stat(p,role,skill,ratingFn){const effective=ratingFn(p,role),base=p?.rating||75;
 const category=skill==='pass'?'MID':skill==='finish'?'ATT':skill==='tackle'?'DEF':skill==='keeper'?'GK':skill==='pace'?'PACE':'ATT';
 return clamp(.58*attr(p,category)+.42*effective-(base-effective)*.13,8,99);
}
function basePosition(manager,index,side){const loc=formationCoordinates(manager.formation||'4-3-3')[index];
 return {x:side===0?6+loc.y*.87:94-loc.y*.87,y:side===0?100-loc.x:loc.x};
}
function playersFor(managers){return managers.flatMap((m,side)=>m.lineup.map((id,index)=>({id,team:side,index,role:formationSlots(m.formation||'4-3-3')[index],...basePosition(m,index,side)})));}
function activePlayers(s,side){return s.players.filter(x=>x.team===side);}
function getPlayer(s,side,index){return s.players[side*11+index];}
function otherSide(side){return 1-side;}
function nearestOpponent(s,from,side){let best=null,d=Infinity;for(const o of activePlayers(s,otherSide(side))){const r=distance(from,o);if(r<d){best=o;d=r;}}return {opponent:best,distance:d};}
function logAction(s,action){action.step=s.step;action.minute=Math.round(s.minute*10)/10;s.actionLog.push(action);
 if(action.type==='goal'){s.goals.push(action);s.score[action.team]++;}
 if(['goal','save','shot','pass','dribble','interception','tackle','corner','kickoff','penalty','through','cross'].includes(action.type)){
  const label={goal:'GOAL',save:'SAVE',shot:'SHOT',pass:'PASS',dribble:'DRIBBLE',interception:'INTERCEPTION',tackle:'TACKLE',corner:'CORNER',kickoff:'KICKOFF',penalty:'PENALTIES',through:'THROUGH BALL',cross:'CROSS'}[action.type];
  s.events.push({step:s.step,minute:Math.floor(s.minute),team:action.team,teamName:s.teamNames[action.team]||'',type:action.type,playerId:action.playerId||null,assistId:action.assistId||null,text:action.text||`${label} · ${s.teamNames[action.team]||''}`});
  if(s.events.length>28)s.events.shift();
 }
}
// Every statistic is derived from the SAME authoritative action history used for match results.
export function computeStats(actions){const stats={possession:[50,50],shots:[0,0],onTarget:[0,0],xg:[0,0],passes:[0,0],completedPasses:[0,0],tackles:[0,0],interceptions:[0,0],saves:[0,0],corners:[0,0],goals:[0,0],chances:[0,0],passesAttempted:[0,0],substitutions:[0,0]};
 let possession=[0,0];for(const a of actions){const t=a.team;if(t!==0&&t!==1)continue;
  if(a.type!=='penalty')possession[t]+=a.possessionDuration||1;
  if(['pass','cross','through'].includes(a.type)){stats.passes[t]++;stats.passesAttempted[t]++;if(a.success)stats.completedPasses[t]++;}
  if(a.type==='sub')stats.substitutions[t]++;
  if(a.type==='tackle')stats.tackles[t]++;
  if(a.type==='interception')stats.interceptions[t]++;
  if(a.type==='corner')stats.corners[t]++;
  if(a.type==='save')stats.saves[t]++;
  if(a.type==='shot'||a.type==='goal'){stats.shots[t]++;stats.chances[t]++;stats.xg[t]+=a.xg||0;if(a.onTarget||a.type==='goal')stats.onTarget[t]++;if(a.type==='goal')stats.goals[t]++;}
 }
 const total=possession[0]+possession[1];if(total){stats.possession=[Math.round(100*possession[0]/total),0];stats.possession[1]=100-stats.possession[0];}
 stats.xg=stats.xg.map(v=>Math.round(v*100)/100);stats.accuracy=stats.passes.map((n,i)=>n?Math.round(100*stats.completedPasses[i]/n):0);return stats;}
export function newSimulation(managers,seed='match'){const p=playersFor(managers);if(p.length!==22||p.some(x=>!x.id))throw Error('Match requires two complete starting elevens');
 const s={seed:seedFrom(seed),initialSeed:seedFrom(seed),step:0,minute:0,teamNames:managers.map(m=>m.team),players:p,ball:{x:50,y:50},possession:0,holder:9,score:[0,0],goals:[],events:[],actionLog:[],statistics:computeStats([]),currentAction:'kickoff',penalties:null,frame:0,phase:'play',lastAssist:null,goalHold:0};
 const h=getPlayer(s,0,9);h.x=49;h.y=50;logAction(s,{type:'kickoff',team:0,playerId:h.id,success:true,text:`${managers[0].team} kick off`});return s;
}
function movePlayers(s,managers){for(const p of s.players){const home=basePosition(managers[p.team],p.index,p.team),attacking=p.team===s.possession;
  const ballShift=(s.ball.x-50)*.19,approach=managers[p.team].tactic||'Balanced';
  const attackingPush=approach==='Attack'?5.3:approach==='Defend'?1.8:3.4;
  const defensivePull=approach==='Defend'?4.7:approach==='Attack'?1.4:2.6;
  const advance=attacking?(p.team===0?attackingPush:-attackingPush):(p.team===0?-defensivePull:defensivePull);
  const targetX=clamp(home.x+ballShift+advance,3,97),targetY=clamp(home.y+(s.ball.y-home.y)*.11,5,95);
  const speed=.15+(p.index===0?-.04:0);p.x+=(targetX-p.x)*speed;p.y+=(targetY-p.y)*speed;
 }
 const h=getPlayer(s,s.possession,s.holder);if(h){const atBall=clamp(.52,0,1);h.x+=(s.ball.x-h.x)*atBall;h.y+=(s.ball.y-h.y)*atBall;}
}
function pickTarget(s,managers,side,current){const team=activePlayers(s,side).filter(p=>p.index!==current.index&&p.index!==0);let sum=0;
 const weighted=team.map(p=>{const forward=(side===0?p.x-current.x:current.x-p.x);const dis=distance(current,p);
  const value=clamp(2.4+forward*.075-dis*.025,0.4,4);sum+=value;return {p,value};});
 let r=random(s)*sum;for(const x of weighted){r-=x.value;if(r<=0)return x.p;}return weighted.at(-1)?.p||current;}
function turnover(s,toSide,at,kind='tackle',defender=null){s.possession=toSide;s.ball={x:clamp(at.x,2,98),y:clamp(at.y,2,98)};
 const side=activePlayers(s,toSide),target=defender||side.reduce((best,p)=>distance(p,s.ball)<distance(best,s.ball)?p:best,side[0]);s.holder=target.index;s.lastAssist=null;
 logAction(s,{type:kind,team:toSide,playerId:target.id,text:`${kind==='interception'?'Intercepted':'Ball recovered'} by ${target.id}`});}
function shot(s,managers,cards,ratingFn,shooter,pressure){const side=s.possession,other=1-side;
 const dist=side===0?100-s.ball.x:s.ball.x,angle=Math.abs(s.ball.y-50),player=cards.get(shooter.id),gk=cards.get(managers[other].lineup[0]);
 const fin=stat(player,shooter.role,'finish',ratingFn),keeper=stat(gk,'GK','keeper',ratingFn);
 const xg=clamp((.025+(.24*Math.exp(-dist/18)))*(1-angle*.007)*(0.7+fin/260)*(1-clamp(pressure,0,25)*.012),.012,.7);
 const onTarget=random(s)<clamp(.28+fin*.005-angle*.002-dist*.0025,0.18,.84);
 const success=onTarget&&random(s)<clamp(xg/(.3+keeper*.0055)+.007,.015,.68);
 const start={...s.ball},goal={x:side===0?100:0,y:50+(random(s)-.5)*13};
 if(success){s.ball=goal;s.goalHold=3;logAction(s,{type:'goal',team:side,playerId:shooter.id,assistId:s.lastAssist,onTarget:true,xg,from:start,to:goal,text:`GOAL! ${player?.name||shooter.id}${s.lastAssist?' · assisted':''}`});}
 else {logAction(s,{type:'shot',team:side,playerId:shooter.id,onTarget,xg,from:start,to:goal,text:`${player?.name||shooter.id} shoots ${onTarget?'on target':'wide'}`});
   if(onTarget){logAction(s,{type:'save',team:other,playerId:gk?.id,text:`${gk?.name||'Keeper'} makes the save`});}
   else if(random(s)<.22){logAction(s,{type:'corner',team:side,text:`Corner to ${s.teamNames[side]}`});}
 }
 // Kickoff after goals. For saves/misses the goalkeeper restarts possession.
 s.possession=success?other:(onTarget?other:random(s)<.18?side:other);
 s.holder=success?9:s.possession===other?0:9;s.lastAssist=null;
 if(!success)s.ball=s.possession===other?{x:other===0?12:88,y:50}:{x:50,y:50};
}
export function stepSimulation(s,managers,cards,ratingFn,period=1){if(s.phase==='finished')return s;
 for(const p of s.players){p.id=managers[p.team].lineup[p.index];p.role=formationSlots(managers[p.team].formation||'4-3-3')[p.index];}
 s.step++;s.minute=period===1?s.step*.5:period===2?45+(s.step-90)*.5:90+(s.step-180)*1.5;
 if(s.goalHold>0){s.goalHold--;s.currentAction='goal celebration';
  if(!s.goalHold){s.ball={x:50,y:50};logAction(s,{type:'kickoff',team:s.possession,playerId:managers[s.possession].lineup[9],text:`${s.teamNames[s.possession]} restart after the goal`});}
  movePlayers(s,managers);s.statistics=computeStats(s.actionLog);s.frame=s.step;return s;
 }
 movePlayers(s,managers);
 const side=s.possession,cur=getPlayer(s,side,s.holder);if(!cur)return s;
 const card=cards.get(cur.id),from={...s.ball};const {opponent,distance:d}=nearestOpponent(s,s.ball,side),press=clamp(15-d,0,15);
 const distToGoal=side===0?100-s.ball.x:s.ball.x;
 const approach=managers[side].tactic||'Balanced',rivalApproach=managers[otherSide(side)].tactic||'Balanced';
 const shootBias=approach==='Attack'?1.22:approach==='Defend'?.77:1;
 const shootChance=(distToGoal<30?clamp(.2+(30-distToGoal)*.012,0.2,.5):distToGoal<42?.045:.002)*shootBias;
 const roll=random(s);const finish=stat(card,cur.role,'finish',ratingFn),passing=stat(card,cur.role,'pass',ratingFn);
 if(roll<shootChance){shot(s,managers,cards,ratingFn,cur,press);s.statistics=computeStats(s.actionLog);movePlayers(s,managers);return s;}
 if(roll<shootChance+.24){ // Individual 1-on-1 attempt
  const defender=cards.get(opponent?.id),attack=stat(card,cur.role,'pace',ratingFn)*.42+stat(card,cur.role,'dribble',ratingFn)*.58;
  const defence=stat(defender,opponent?.role||'CB','tackle',ratingFn);
  const won=random(s)<clamp(.38+(attack-defence)*.007+(d-8)*.01+(approach==='Attack'?.02:0)-(rivalApproach==='Defend'?.04:0),.12,.82);
  if(won){s.ball={x:clamp(from.x+(side===0?1:-1)*(2+random(s)*5),3,97),y:clamp(from.y+(random(s)-.5)*10,4,96)};
    logAction(s,{type:'dribble',team:side,playerId:cur.id,success:true,from,to:{...s.ball},text:`${card?.name||cur.id} beats a defender`});}
  else turnover(s,otherSide(side),from,'tackle',opponent);
 }else{
  const target=pickTarget(s,managers,side,cur),dis=distance(from,target),forward=(side===0?target.x-from.x:from.x-target.x);
  const type=forward>15?'through':Math.abs(target.y-from.y)>30?'cross':'pass';
  const defender=nearestOpponent(s,target,side),defCard=cards.get(defender.opponent?.id);
  const interception=stat(defCard,defender.opponent?.role||'CB','tackle',ratingFn);
  const quality=clamp(.82+(passing-75)*.004-dis*.003-press*.014-(interception-75)*.002+(type==='through'?-.09:0)+(approach==='Defend'?.023:approach==='Attack'?-.025:0)-(rivalApproach==='Attack'?.025:0),.25,.98);
  const success=random(s)<quality;
  const dest={x:clamp(target.x+(side===0?3:-3),3,97),y:clamp(target.y,3,97)};
  logAction(s,{type,team:side,playerId:cur.id,targetId:target.id,success,from,to:dest,text:success?`${card?.name||cur.id} finds ${cards.get(target.id)?.name||target.id}`:`${card?.name||cur.id}'s pass is intercepted`});
  if(success){s.ball=dest;s.holder=target.index;s.lastAssist=cur.id;}
  else turnover(s,otherSide(side),dest,'interception',defender.opponent);
 }
 movePlayers(s,managers);s.statistics=computeStats(s.actionLog);s.currentAction=s.actionLog.at(-1)?.type||'play';s.frame=s.step;
 return s;
}
export function resolvePenalties(s,managers,cards,ratingFn){if(s.penalties)return s.penalties;
 let scores=[0,0],round=0;const shots=[];
 const kick=(side,index)=>{const team=managers[side],opponent=managers[1-side];const shooters=team.lineup.slice(1),id=shooters[index%shooters.length],p=cards.get(id),gk=cards.get(opponent.lineup[0]);
  const skill=stat(p,formationSlots(team.formation||'4-3-3')[(index%10)+1],'finish',ratingFn),save=stat(gk,'GK','keeper',ratingFn);
  const goal=random(s)<clamp(.72+(skill-save)*.003,0.48,.91);
  if(goal)scores[side]++;shots.push({team:side,id,goal});return goal;};
 for(let i=0;i<5;i++){kick(0,i);kick(1,i);}
 for(round=5;scores[0]===scores[1]&&round<30;round++){kick(0,round);kick(1,round);}
 if(scores[0]===scores[1]){ // tie-breaking pair of kicks from next takers; keep paired scoring.
  while(scores[0]===scores[1]){kick(0,round);kick(1,round);round++;}
 }
 s.penalties={scores,shots,winner:scores[0]>scores[1]?0:1};logAction(s,{type:'penalty',team:s.penalties.winner,score:scores,text:`Penalty shootout ${scores.join('–')}`});return s.penalties;
}
export function validateSimulation(s){const computed=computeStats(s.actionLog);if(s.score[0]!==computed.goals[0]||s.score[1]!==computed.goals[1])throw Error('Match score diverged from goal events');
 if(!s.players||s.players.length!==22||s.players.some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.y)))throw Error('Invalid animated match state');
 return true;
}
