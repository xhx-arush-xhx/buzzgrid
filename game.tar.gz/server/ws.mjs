import {createHash} from 'node:crypto';
/** Dependency-free, masked RFC6455 text WebSocket support for modern browsers. */
export function upgrade(request,socket,head,onMessage,onClose){
 const key=request.headers['sec-websocket-key'];
 if(request.headers.upgrade?.toLowerCase()!=='websocket'||!key){socket.destroy();return;}
 const accept=createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
 socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');
 let buffer=Buffer.alloc(0),closed=false;
 const send=(value,opcode=1)=>{
  if(socket.destroyed||closed)return;
  const payload=Buffer.from(typeof value==='string'?value:JSON.stringify(value));
  let head;
  if(payload.length<126){head=Buffer.from([0x80|opcode,payload.length]);}
  else if(payload.length<65536){head=Buffer.alloc(4);head[0]=0x80|opcode;head[1]=126;head.writeUInt16BE(payload.length,2);}
  else {head=Buffer.alloc(10);head[0]=0x80|opcode;head[1]=127;head.writeBigUInt64BE(BigInt(payload.length),2);}
  if(socket.writableLength>1500000){socket.destroy();return;}
  socket.write(Buffer.concat([head,payload]));
 };
 const close=()=>{if(closed)return;closed=true;onClose?.();};
 socket.on('close',close);socket.on('error',close);
 socket.on('data',chunk=>{
  buffer=Buffer.concat([buffer,chunk]);if(buffer.length>500000){socket.destroy();return;}
  while(buffer.length>=2){
   const b0=buffer[0],b1=buffer[1],opcode=b0&15,masked=Boolean(b1&128);
   if(!(b0&128)||!masked){socket.destroy();return;}
   let pos=2,len=b1&127;
   if(len===126){if(buffer.length<4)return;len=buffer.readUInt16BE(2);pos=4;}
   if(len===127){if(buffer.length<10)return;const large=buffer.readBigUInt64BE(2);if(large>250000n){socket.destroy();return;}len=Number(large);pos=10;}
   if(len>250000){socket.destroy();return;}
   if(buffer.length<pos+4+len)return;
   const mask=buffer.subarray(pos,pos+4);pos+=4;
   const payload=Buffer.from(buffer.subarray(pos,pos+len));for(let i=0;i<payload.length;i++)payload[i]^=mask[i%4];
   buffer=buffer.subarray(pos+len);
   if(opcode===8){socket.end();close();return;}
   if(opcode===9){send(payload.toString('utf8'),10);continue;}
   if(opcode!==1){socket.destroy();return;}
   try{const message=JSON.parse(payload.toString('utf8'));onMessage(message);}catch(e){send({type:'error',message:'Invalid message payload'});}
  }
 });
 if(head.length)socket.emit('data',head);
 return {send,close:()=>socket.end(),socket};
}
