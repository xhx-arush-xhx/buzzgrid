/** Wikimedia photo URLs and identity records. Never infer identity from a file name alone. */
const SAFE_HOST='upload.wikimedia.org';
export const isValidPhotoURL=value=>{
 try{
  const url=new URL(value);
  return url.protocol==='https:'&&url.hostname===SAFE_HOST&&url.pathname.startsWith('/wikipedia/commons/');
 }catch{return false;}
};
export function originalURL(entry){
 const raw=entry?.imageUrl;
 if(!isValidPhotoURL(raw))return null;
 const u=new URL(raw);u.search='';u.hash='';
 return u.href;
}
/**
 * Thumbnail paths are derived from the catalog's original Commons file URL.
 * Legacy catalog URLs sometimes used thumb.wikimedia.org, which is not the Commons
 * upload CDN. Do not trust that host. Wikimedia uses /commons/thumb/H/H2/name/Npx-name.
 */
export function thumbnailURL(entry,requestedWidth=360){
 const original=originalURL(entry);if(!original)return null;
 const width=Number(entry.imageWidth);
 const px=Math.floor(requestedWidth);
 if(!Number.isInteger(px)||px<64||px>960)throw Error('Invalid requested thumbnail width');
 // Commons may reject requests to upscale photos beyond their original dimensions.
 if(!Number.isFinite(width)||width<px)return original;
 const u=new URL(original);
 const match=u.pathname.match(/^\/wikipedia\/commons\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+)$/);
 if(!match)return original;
 if(!/\.(?:jpe?g|png|webp)$/i.test(match[3]))return original;
 u.pathname=`/wikipedia/commons/thumb/${match[1]}/${match[2]}/${match[3]}/${px}px-${match[3]}`;
 return u.href;
}
export function catalogIntegrity(players,photos){
 const found=new Map(photos.map(x=>[x.id,x]));
 const ids=new Set(),sources=new Map(),errors=[],warnings=[];
 if(players.length!==1000||photos.length!==1000)errors.push(`Expected exactly 1,000 players and photo records: ${players.length}/${photos.length}`);
 for(const p of players){
  if(ids.has(p.id))errors.push(`Duplicate ID ${p.id}`);ids.add(p.id);
  const ph=found.get(p.id);
  if(!ph){errors.push(`Missing photo record for ${p.id}`);continue;}
  if(ph.name!==p.name)errors.push(`${p.id}: photo belongs to name '${ph.name}', not '${p.name}'`);
  if(ph.position!==p.position)warnings.push(`${p.id}: position metadata differs`);
  if(ph.imageUrl){
   if(!originalURL(ph))errors.push(`${p.id}: invalid Commons photo origin`);
   const src=originalURL(ph);
   if(src&&sources.has(src))errors.push(`Duplicate image for ${sources.get(src)} and ${p.id}`);
   if(src)sources.set(src,p.id);
  }
  if(!ph.imageUrl && ph.status!=='not_verified')warnings.push(`${p.id}: missing photo, status '${ph.status}'`);
 }
 return {ok:!errors.length,errors,warnings,matched:players.length-errors.length,withPhotos:photos.filter(p=>originalURL(p)).length,missingPhotos:photos.filter(p=>!originalURL(p)).length,manualReview:photos.filter(p=>p.reviewRequired).length};
}
